-- phpMyAdmin SQL Dump
-- version 4.7.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Creato il: Dic 04, 2017 alle 16:34
-- Versione del server: 5.6.35
-- Versione PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meta_dam`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `bytestream_types_tbl`
--

DROP TABLE IF EXISTS `bytestream_types_tbl`;
CREATE TABLE `bytestream_types_tbl` (
  `bytestream_type_id` int(11) NOT NULL,
  `bytestream_type_instance` varchar(255) NOT NULL,
  `bytestream_type_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_detail_tbl`
--

DROP TABLE IF EXISTS `documents_detail_tbl`;
CREATE TABLE `documents_detail_tbl` (
  `document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_document_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_language_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_user_id` int(10) UNSIGNED NOT NULL,
  `document_detail_modificationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `document_detail_status` varchar(9) NOT NULL DEFAULT 'DRAFT',
  `document_detail_translated` tinyint(1) NOT NULL,
  `document_detail_object` longtext NOT NULL,
  `document_detail_isVisible` tinyint(1) NOT NULL DEFAULT '1',
  `document_detail_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_datetime_tbl`
--

DROP TABLE IF EXISTS `documents_index_datetime_tbl`;
CREATE TABLE `documents_index_datetime_tbl` (
  `document_index_datetime_id` int(10) UNSIGNED NOT NULL,
  `document_index_datetime_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_datetime_name` varchar(100) NOT NULL,
  `document_index_datetime_value` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_date_tbl`
--

DROP TABLE IF EXISTS `documents_index_date_tbl`;
CREATE TABLE `documents_index_date_tbl` (
  `document_index_date_id` int(10) UNSIGNED NOT NULL,
  `document_index_date_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_date_name` varchar(100) NOT NULL,
  `document_index_date_value` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_fulltext_tbl`
--

DROP TABLE IF EXISTS `documents_index_fulltext_tbl`;
CREATE TABLE `documents_index_fulltext_tbl` (
  `document_index_fulltext_id` int(10) UNSIGNED NOT NULL,
  `document_index_fulltext_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_fulltext_name` varchar(100) NOT NULL,
  `document_index_fulltext_value` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_int_tbl`
--

DROP TABLE IF EXISTS `documents_index_int_tbl`;
CREATE TABLE `documents_index_int_tbl` (
  `document_index_int_id` int(10) UNSIGNED NOT NULL,
  `document_index_int_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_int_name` varchar(100) NOT NULL,
  `document_index_int_value` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_text_tbl`
--

DROP TABLE IF EXISTS `documents_index_text_tbl`;
CREATE TABLE `documents_index_text_tbl` (
  `document_index_text_id` int(10) UNSIGNED NOT NULL,
  `document_index_text_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_text_name` varchar(100) NOT NULL,
  `document_index_text_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_time_tbl`
--

DROP TABLE IF EXISTS `documents_index_time_tbl`;
CREATE TABLE `documents_index_time_tbl` (
  `document_index_time_id` int(10) UNSIGNED NOT NULL,
  `document_index_time_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_time_name` varchar(100) NOT NULL,
  `document_index_time_value` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_tbl`
--

DROP TABLE IF EXISTS `documents_tbl`;
CREATE TABLE `documents_tbl` (
  `document_id` int(10) UNSIGNED NOT NULL,
  `document_type` varchar(255) DEFAULT NULL,
  `document_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `document_FK_site_id` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `jobs_tbl`
--

DROP TABLE IF EXISTS `jobs_tbl`;
CREATE TABLE `jobs_tbl` (
  `job_id` int(10) UNSIGNED NOT NULL,
  `job_type` enum('INTERACTIVE','BACKGROUND') NOT NULL DEFAULT 'INTERACTIVE',
  `job_name` varchar(255) NOT NULL,
  `job_params` text NOT NULL,
  `job_description` text,
  `job_message` text,
  `job_status` enum('NOT_STARTED','RUNNING','COMPLETED','ERROR') NOT NULL DEFAULT 'NOT_STARTED',
  `job_progress` int(3) NOT NULL DEFAULT '0',
  `job_modificationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `joins_tbl`
--

DROP TABLE IF EXISTS `joins_tbl`;
CREATE TABLE `joins_tbl` (
  `join_id` int(1) UNSIGNED NOT NULL,
  `join_FK_source_id` int(10) UNSIGNED NOT NULL,
  `join_FK_dest_id` int(10) UNSIGNED NOT NULL,
  `join_objectName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `languages_tbl`
--

DROP TABLE IF EXISTS `languages_tbl`;
CREATE TABLE `languages_tbl` (
  `language_id` int(10) UNSIGNED NOT NULL,
  `language_name` varchar(100) NOT NULL DEFAULT '',
  `language_code` varchar(10) NOT NULL DEFAULT '',
  `language_FK_country_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `language_isDefault` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `language_order` int(4) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `languages_tbl`
--

INSERT INTO `languages_tbl` (`language_id`, `language_name`, `language_code`, `language_FK_country_id`, `language_isDefault`, `language_order`) VALUES
(1, 'Italiano', 'it', 61, 1, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `mediadetails_tbl`
--

DROP TABLE IF EXISTS `mediadetails_tbl`;
CREATE TABLE `mediadetails_tbl` (
  `mediadetail_id` int(10) UNSIGNED NOT NULL,
  `mediadetail_FK_media_id` int(10) UNSIGNED NOT NULL,
  `media_FK_language_id` int(10) UNSIGNED NOT NULL,
  `media_FK_user_id` int(10) UNSIGNED NOT NULL,
  `media_modificationDate` datetime DEFAULT '0000-00-00 00:00:00',
  `media_title` varchar(255) NOT NULL DEFAULT '',
  `media_category` varchar(255) DEFAULT NULL,
  `media_date` varchar(100) DEFAULT NULL,
  `media_copyright` varchar(255) DEFAULT NULL,
  `media_description` text,
  `media_tags` varchar(255) NOT NULL,
  `media_licenseEnd` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `media_tbl`
--

DROP TABLE IF EXISTS `media_tbl`;
CREATE TABLE `media_tbl` (
  `media_id` int(10) UNSIGNED NOT NULL,
  `media_FK_site_id` int(10) UNSIGNED NOT NULL,
  `media_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `media_fileName` varchar(255) NOT NULL DEFAULT '',
  `media_size` int(4) UNSIGNED NOT NULL DEFAULT '0',
  `media_type` enum('IMAGE','OFFICE','PDF','ARCHIVE','FLASH','AUDIO','VIDEO','OTHER') NOT NULL DEFAULT 'IMAGE',
  `media_author` varchar(255) DEFAULT '',
  `media_originalFileName` varchar(255) NOT NULL DEFAULT '',
  `media_zoom` tinyint(1) DEFAULT '0',
  `media_download` int(10) NOT NULL DEFAULT '0',
  `media_md5` varchar(32) NOT NULL,
  `media_watermark` tinyint(1) NOT NULL DEFAULT '0',
  `media_allowDownload` tinyint(1) NOT NULL DEFAULT '1',
  `media_thumbFileName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `menudetails_tbl`
--

DROP TABLE IF EXISTS `menudetails_tbl`;
CREATE TABLE `menudetails_tbl` (
  `menudetail_id` int(10) UNSIGNED NOT NULL,
  `menudetail_FK_menu_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `menudetail_FK_language_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `menudetail_title` text,
  `menudetail_keywords` text,
  `menudetail_description` text,
  `menudetail_subject` text,
  `menudetail_creator` text,
  `menudetail_publisher` text,
  `menudetail_contributor` text,
  `menudetail_type` text,
  `menudetail_identifier` text,
  `menudetail_source` text,
  `menudetail_relation` text,
  `menudetail_coverage` text,
  `menudetail_isVisible` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `menudetail_titleLink` varchar(255) NOT NULL DEFAULT '',
  `menudetail_linkDescription` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `menus_tbl`
--

DROP TABLE IF EXISTS `menus_tbl`;
CREATE TABLE `menus_tbl` (
  `menu_id` int(10) UNSIGNED NOT NULL,
  `menu_parentId` int(10) UNSIGNED DEFAULT '0',
  `menu_FK_site_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `menu_pageType` varchar(100) NOT NULL DEFAULT '',
  `menu_order` int(4) UNSIGNED DEFAULT '0',
  `menu_hasPreview` tinyint(1) UNSIGNED DEFAULT '1',
  `menu_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `menu_modificationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `menu_type` enum('HOMEPAGE','PAGE','SYSTEM') NOT NULL DEFAULT 'PAGE',
  `menu_url` varchar(255) DEFAULT '',
  `menu_isLocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `menu_hasComment` tinyint(1) NOT NULL DEFAULT '0',
  `menu_printPdf` tinyint(1) NOT NULL DEFAULT '0',
  `menu_extendsPermissions` tinyint(1) NOT NULL DEFAULT '0',
  `menu_cssClass` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `registry_tbl`
--

DROP TABLE IF EXISTS `registry_tbl`;
CREATE TABLE `registry_tbl` (
  `registry_id` int(11) NOT NULL,
  `registry_path` varchar(255) NOT NULL DEFAULT '',
  `registry_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_datetime_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_datetime_tbl`;
CREATE TABLE `simple_documents_index_datetime_tbl` (
  `simple_document_index_datetime_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_datetime_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_datetime_name` varchar(255) NOT NULL,
  `simple_document_index_datetime_value` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_date_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_date_tbl`;
CREATE TABLE `simple_documents_index_date_tbl` (
  `simple_document_index_date_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_date_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_date_name` varchar(255) NOT NULL,
  `simple_document_index_date_value` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_fulltext_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_fulltext_tbl`;
CREATE TABLE `simple_documents_index_fulltext_tbl` (
  `simple_document_index_fulltext_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_fulltext_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_fulltext_name` varchar(70) NOT NULL,
  `simple_document_index_fulltext_value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_int_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_int_tbl`;
CREATE TABLE `simple_documents_index_int_tbl` (
  `simple_document_index_int_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_int_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_int_name` varchar(255) NOT NULL,
  `simple_document_index_int_value` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_text_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_text_tbl`;
CREATE TABLE `simple_documents_index_text_tbl` (
  `simple_document_index_text_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_text_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_text_name` varchar(255) NOT NULL,
  `simple_document_index_text_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_time_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_time_tbl`;
CREATE TABLE `simple_documents_index_time_tbl` (
  `simple_document_index_time_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_time_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_time_name` varchar(255) NOT NULL,
  `simple_document_index_time_value` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_tbl`
--

DROP TABLE IF EXISTS `simple_documents_tbl`;
CREATE TABLE `simple_documents_tbl` (
  `simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_type` varchar(255) NOT NULL,
  `simple_document_FK_site_id` int(10) UNSIGNED NOT NULL,
  `simple_document_object` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `usergroups_tbl`
--

DROP TABLE IF EXISTS `usergroups_tbl`;
CREATE TABLE `usergroups_tbl` (
  `usergroup_id` int(11) NOT NULL,
  `usergroup_name` varchar(50) NOT NULL DEFAULT '',
  `usergroup_backEndAccess` tinyint(1) NOT NULL DEFAULT '0',
  `usergroup_FK_site_id` int(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `userlogs_tbl`
--

DROP TABLE IF EXISTS `userlogs_tbl`;
CREATE TABLE `userlogs_tbl` (
  `userlog_id` int(10) UNSIGNED NOT NULL,
  `userlog_FK_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `userlog_session` varchar(50) NOT NULL DEFAULT '',
  `userlog_ip` varchar(50) NOT NULL DEFAULT '',
  `userlog_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `userlog_lastAction` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `users_tbl`
--

DROP TABLE IF EXISTS `users_tbl`;
CREATE TABLE `users_tbl` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_FK_usergroup_id` int(10) UNSIGNED NOT NULL DEFAULT '2',
  `user_FK_site_id` int(10) UNSIGNED NOT NULL,
  `user_dateCreation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_isActive` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `user_loginId` varchar(100) NOT NULL DEFAULT '',
  `user_password` varchar(100) NOT NULL DEFAULT '',
  `user_firstName` varchar(100) NOT NULL DEFAULT '',
  `user_lastName` varchar(100) NOT NULL DEFAULT '',
  `user_email` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `users_tbl`
--

INSERT INTO `users_tbl` (`user_id`, `user_FK_usergroup_id`, `user_FK_site_id`, `user_dateCreation`, `user_isActive`, `user_loginId`, `user_password`, `user_firstName`, `user_lastName`, `user_email`) VALUES
(1, 1, 0, '0000-00-00 00:00:00', 1, 'admin', '21232F297A57A5A743894A0E4A801FC3', 'Amministratore', 'Amministratore', 'admin@admin.com');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `bytestream_types_tbl`
--
ALTER TABLE `bytestream_types_tbl`
  ADD PRIMARY KEY (`bytestream_type_id`);

--
-- Indici per le tabelle `documents_detail_tbl`
--
ALTER TABLE `documents_detail_tbl`
  ADD PRIMARY KEY (`document_detail_id`),
  ADD KEY `document_detail_fk_document_id` (`document_detail_FK_document_id`),
  ADD KEY `document_detail_fk_language_id` (`document_detail_FK_language_id`),
  ADD KEY `document_detail_fk_user_id` (`document_detail_FK_user_id`),
  ADD KEY `document_detail_status` (`document_detail_status`);

--
-- Indici per le tabelle `documents_index_datetime_tbl`
--
ALTER TABLE `documents_index_datetime_tbl`
  ADD PRIMARY KEY (`document_index_datetime_id`),
  ADD KEY `document_index_datetime_fk` (`document_index_datetime_FK_document_detail_id`),
  ADD KEY `document_index_datetime_name` (`document_index_datetime_name`,`document_index_datetime_value`);

--
-- Indici per le tabelle `documents_index_date_tbl`
--
ALTER TABLE `documents_index_date_tbl`
  ADD PRIMARY KEY (`document_index_date_id`),
  ADD KEY `document_index_date_fk` (`document_index_date_FK_document_detail_id`),
  ADD KEY `document_index_date_name` (`document_index_date_name`,`document_index_date_value`);

--
-- Indici per le tabelle `documents_index_fulltext_tbl`
--
ALTER TABLE `documents_index_fulltext_tbl`
  ADD PRIMARY KEY (`document_index_fulltext_id`),
  ADD KEY `document_index_fulltext_name` (`document_index_fulltext_name`),
  ADD KEY `document_index_fulltext_FK_document_detail_id` (`document_index_fulltext_FK_document_detail_id`);
ALTER TABLE `documents_index_fulltext_tbl` ADD FULLTEXT KEY `document_index_fulltext_value` (`document_index_fulltext_value`);

--
-- Indici per le tabelle `documents_index_int_tbl`
--
ALTER TABLE `documents_index_int_tbl`
  ADD PRIMARY KEY (`document_index_int_id`),
  ADD KEY `document_index_int_fk` (`document_index_int_FK_document_detail_id`),
  ADD KEY `document_index_int_name` (`document_index_int_name`,`document_index_int_value`);

--
-- Indici per le tabelle `documents_index_text_tbl`
--
ALTER TABLE `documents_index_text_tbl`
  ADD PRIMARY KEY (`document_index_text_id`),
  ADD KEY `document_index_text_fk` (`document_index_text_FK_document_detail_id`),
  ADD KEY `document_index_text_name` (`document_index_text_name`(70),`document_index_text_value`);

--
-- Indici per le tabelle `documents_index_time_tbl`
--
ALTER TABLE `documents_index_time_tbl`
  ADD PRIMARY KEY (`document_index_time_id`),
  ADD KEY `document_index_time_fk` (`document_index_time_FK_document_detail_id`),
  ADD KEY `document_index_time_name` (`document_index_time_name`,`document_index_time_value`);

--
-- Indici per le tabelle `documents_tbl`
--
ALTER TABLE `documents_tbl`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `document_type` (`document_type`),
  ADD KEY `document_FK_site_id` (`document_FK_site_id`);

--
-- Indici per le tabelle `jobs_tbl`
--
ALTER TABLE `jobs_tbl`
  ADD PRIMARY KEY (`job_id`);

--
-- Indici per le tabelle `joins_tbl`
--
ALTER TABLE `joins_tbl`
  ADD PRIMARY KEY (`join_id`),
  ADD KEY `join_FK_source_id` (`join_FK_source_id`),
  ADD KEY `join_FK_dest_id` (`join_FK_dest_id`),
  ADD KEY `join_objectName` (`join_objectName`);

--
-- Indici per le tabelle `languages_tbl`
--
ALTER TABLE `languages_tbl`
  ADD PRIMARY KEY (`language_id`),
  ADD KEY `language_FK_country_id` (`language_FK_country_id`);

--
-- Indici per le tabelle `mediadetails_tbl`
--
ALTER TABLE `mediadetails_tbl`
  ADD PRIMARY KEY (`mediadetail_id`),
  ADD KEY `mediadetail_FK_media_id` (`mediadetail_FK_media_id`),
  ADD KEY `media_FK_language_id` (`media_FK_language_id`),
  ADD KEY `media_FK_user_id` (`media_FK_user_id`);

--
-- Indici per le tabelle `media_tbl`
--
ALTER TABLE `media_tbl`
  ADD PRIMARY KEY (`media_id`),
  ADD KEY `media_FK_site_id` (`media_FK_site_id`),
  ADD KEY `media_type` (`media_type`);

--
-- Indici per le tabelle `menudetails_tbl`
--
ALTER TABLE `menudetails_tbl`
  ADD PRIMARY KEY (`menudetail_id`),
  ADD KEY `menudetail_FK_menu_id` (`menudetail_FK_menu_id`),
  ADD KEY `menudetail_FK_language_id` (`menudetail_FK_language_id`);

--
-- Indici per le tabelle `menus_tbl`
--
ALTER TABLE `menus_tbl`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `menu_pageType` (`menu_pageType`),
  ADD KEY `menu_FK_site_id` (`menu_FK_site_id`),
  ADD KEY `menu_parentId` (`menu_parentId`);

--
-- Indici per le tabelle `registry_tbl`
--
ALTER TABLE `registry_tbl`
  ADD PRIMARY KEY (`registry_id`),
  ADD KEY `registry_path` (`registry_path`);

--
-- Indici per le tabelle `simple_documents_index_datetime_tbl`
--
ALTER TABLE `simple_documents_index_datetime_tbl`
  ADD PRIMARY KEY (`simple_document_index_datetime_id`),
  ADD KEY `simple_document_index_datetime_fk` (`simple_document_index_datetime_FK_simple_document_id`),
  ADD KEY `simple_document_index_datetime_name` (`simple_document_index_datetime_name`(250));

--
-- Indici per le tabelle `simple_documents_index_date_tbl`
--
ALTER TABLE `simple_documents_index_date_tbl`
  ADD PRIMARY KEY (`simple_document_index_date_id`),
  ADD KEY `simple_document_index_date_fk` (`simple_document_index_date_FK_simple_document_id`),
  ADD KEY `simple_document_index_date_name` (`simple_document_index_date_name`);

--
-- Indici per le tabelle `simple_documents_index_fulltext_tbl`
--
ALTER TABLE `simple_documents_index_fulltext_tbl`
  ADD PRIMARY KEY (`simple_document_index_fulltext_id`),
  ADD KEY `simple_document_index_fulltext_FK_simple_document_detail_id` (`simple_document_index_fulltext_FK_simple_document_id`),
  ADD KEY `simple_document_index_fulltext_name` (`simple_document_index_fulltext_name`);
ALTER TABLE `simple_documents_index_fulltext_tbl` ADD FULLTEXT KEY `simple_document_index_fulltext_value` (`simple_document_index_fulltext_value`);

--
-- Indici per le tabelle `simple_documents_index_int_tbl`
--
ALTER TABLE `simple_documents_index_int_tbl`
  ADD PRIMARY KEY (`simple_document_index_int_id`),
  ADD KEY `simple_document_index_int_fk` (`simple_document_index_int_FK_simple_document_id`),
  ADD KEY `simple_document_index_int_name` (`simple_document_index_int_name`);

--
-- Indici per le tabelle `simple_documents_index_text_tbl`
--
ALTER TABLE `simple_documents_index_text_tbl`
  ADD PRIMARY KEY (`simple_document_index_text_id`),
  ADD KEY `simple_document_index_text_fk` (`simple_document_index_text_FK_simple_document_id`),
  ADD KEY `simple_document_index_text_name` (`simple_document_index_text_name`);

--
-- Indici per le tabelle `simple_documents_index_time_tbl`
--
ALTER TABLE `simple_documents_index_time_tbl`
  ADD PRIMARY KEY (`simple_document_index_time_id`),
  ADD KEY `simple_document_index_time_fk` (`simple_document_index_time_FK_simple_document_id`),
  ADD KEY `simple_document_index_time_name` (`simple_document_index_time_name`);

--
-- Indici per le tabelle `simple_documents_tbl`
--
ALTER TABLE `simple_documents_tbl`
  ADD PRIMARY KEY (`simple_document_id`),
  ADD KEY `simple_document_type` (`simple_document_type`),
  ADD KEY `simple_document_FK_site_id` (`simple_document_FK_site_id`);

--
-- Indici per le tabelle `usergroups_tbl`
--
ALTER TABLE `usergroups_tbl`
  ADD PRIMARY KEY (`usergroup_id`),
  ADD KEY `usergroup_FK_site_id` (`usergroup_FK_site_id`);

--
-- Indici per le tabelle `userlogs_tbl`
--
ALTER TABLE `userlogs_tbl`
  ADD PRIMARY KEY (`userlog_id`),
  ADD KEY `userlog_FK_user_id` (`userlog_FK_user_id`);

--
-- Indici per le tabelle `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_FK_usergroup_id` (`user_FK_usergroup_id`),
  ADD KEY `user_FK_site_id` (`user_FK_site_id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `bytestream_types_tbl`
--
ALTER TABLE `bytestream_types_tbl`
  MODIFY `bytestream_type_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_detail_tbl`
--
ALTER TABLE `documents_detail_tbl`
  MODIFY `document_detail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_index_datetime_tbl`
--
ALTER TABLE `documents_index_datetime_tbl`
  MODIFY `document_index_datetime_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_index_date_tbl`
--
ALTER TABLE `documents_index_date_tbl`
  MODIFY `document_index_date_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_index_fulltext_tbl`
--
ALTER TABLE `documents_index_fulltext_tbl`
  MODIFY `document_index_fulltext_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_index_int_tbl`
--
ALTER TABLE `documents_index_int_tbl`
  MODIFY `document_index_int_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_index_text_tbl`
--
ALTER TABLE `documents_index_text_tbl`
  MODIFY `document_index_text_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_index_time_tbl`
--
ALTER TABLE `documents_index_time_tbl`
  MODIFY `document_index_time_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `documents_tbl`
--
ALTER TABLE `documents_tbl`
  MODIFY `document_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `jobs_tbl`
--
ALTER TABLE `jobs_tbl`
  MODIFY `job_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT per la tabella `joins_tbl`
--
ALTER TABLE `joins_tbl`
  MODIFY `join_id` int(1) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `languages_tbl`
--
ALTER TABLE `languages_tbl`
  MODIFY `language_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT per la tabella `mediadetails_tbl`
--
ALTER TABLE `mediadetails_tbl`
  MODIFY `mediadetail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `media_tbl`
--
ALTER TABLE `media_tbl`
  MODIFY `media_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `menudetails_tbl`
--
ALTER TABLE `menudetails_tbl`
  MODIFY `menudetail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `menus_tbl`
--
ALTER TABLE `menus_tbl`
  MODIFY `menu_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `registry_tbl`
--
ALTER TABLE `registry_tbl`
  MODIFY `registry_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_index_datetime_tbl`
--
ALTER TABLE `simple_documents_index_datetime_tbl`
  MODIFY `simple_document_index_datetime_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_index_date_tbl`
--
ALTER TABLE `simple_documents_index_date_tbl`
  MODIFY `simple_document_index_date_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_index_fulltext_tbl`
--
ALTER TABLE `simple_documents_index_fulltext_tbl`
  MODIFY `simple_document_index_fulltext_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_index_int_tbl`
--
ALTER TABLE `simple_documents_index_int_tbl`
  MODIFY `simple_document_index_int_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_index_text_tbl`
--
ALTER TABLE `simple_documents_index_text_tbl`
  MODIFY `simple_document_index_text_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_index_time_tbl`
--
ALTER TABLE `simple_documents_index_time_tbl`
  MODIFY `simple_document_index_time_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `simple_documents_tbl`
--
ALTER TABLE `simple_documents_tbl`
  MODIFY `simple_document_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `usergroups_tbl`
--
ALTER TABLE `usergroups_tbl`
  MODIFY `usergroup_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `userlogs_tbl`
--
ALTER TABLE `userlogs_tbl`
  MODIFY `userlog_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT per la tabella `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
