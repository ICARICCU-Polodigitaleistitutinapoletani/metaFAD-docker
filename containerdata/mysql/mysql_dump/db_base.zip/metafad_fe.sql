-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Creato il: Mag 05, 2021 alle 13:03
-- Versione del server: 5.7.18
-- Versione PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `metafad_portale`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `countries_tbl`
--

DROP TABLE IF EXISTS `countries_tbl`;
CREATE TABLE `countries_tbl` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(255) DEFAULT NULL,
  `country_639_2` char(3) DEFAULT NULL,
  `country_639_1` char(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `countries_tbl`
--

INSERT INTO `countries_tbl` (`country_id`, `country_name`, `country_639_2`, `country_639_1`) VALUES
(1, 'Afrikaans', 'afr', 'af'),
(2, 'Albanian', 'alb', 'sq'),
(3, 'Amharic', 'amh', 'am'),
(4, 'Arabic', 'ara', 'ar'),
(5, 'Armenian', 'arm', 'hy'),
(6, 'Assamese', 'asm', 'as'),
(7, 'Avestan', 'ave', 'ae'),
(8, 'Aymara', 'aym', 'ay'),
(9, 'Azerbaijani', 'aze', 'az'),
(10, 'Bashkir', 'bak', 'ba'),
(11, 'Basque', 'baq', 'eu'),
(12, 'Belarusian', 'bel', 'be'),
(13, 'Bengali', 'ben', 'bn'),
(14, 'Bihari', 'bih', 'bh'),
(15, 'Bislama', 'bis', 'bi'),
(16, 'Bosnian', 'bos', 'bs'),
(17, 'Breton', 'bre', 'br'),
(18, 'Bulgarian', 'bul', 'bg'),
(19, 'Burmese', 'bur', 'my'),
(20, 'Catalan', 'cat', 'ca'),
(21, 'Chamorro', 'cha', 'ch'),
(22, 'Chechen', 'che', 'ce'),
(23, 'Chichewa', 'nya', 'ny'),
(24, 'Chinese', 'chi', 'zh'),
(25, 'Church Slavic', 'chu', 'cu'),
(26, 'Chuvash', 'chv', 'cv'),
(27, 'Cornish', 'cor', 'kw'),
(28, 'Corsican', 'cos', 'co'),
(29, 'Croatian', 'hrv', 'hr'),
(30, 'Czech', 'cze', 'cs'),
(31, 'Danish', 'dan', 'da'),
(32, 'Dutch', 'nld', 'nl'),
(33, 'Dzongkha', 'dzo', 'dz'),
(34, 'English', 'eng', 'en'),
(35, 'Esperanto', 'epo', 'eo'),
(36, 'Estonian', 'est', 'et'),
(37, 'Faroese', 'fao', 'fo'),
(38, 'Fijian', 'fij', 'fj'),
(39, 'Finnish', 'fin', 'fi'),
(40, 'French', 'fra', 'fr'),
(41, 'Frisian', 'fry', 'fy'),
(42, 'Gaelic', 'gla', 'gd'),
(43, 'Galician', 'glg', 'gl'),
(44, 'Georgian', 'geo', 'ka'),
(45, 'German', 'deu', 'de'),
(46, 'Greek (Modern)', 'ell', 'el'),
(47, 'Guarani', 'grn', 'gn'),
(48, 'Gujarati', 'guj', 'gu'),
(49, 'Hebrew', 'heb', 'he'),
(50, 'Herero', 'her', 'hz'),
(51, 'Hindi', 'hin', 'hi'),
(52, 'Hiri Motu', 'hmo', 'ho'),
(53, 'Hungarian', 'hun', 'hu'),
(54, 'Icelandic', 'isl', 'is'),
(55, 'Indonesian', 'ind', 'id'),
(56, 'Interlingua (International Auxiliary Language Association)', 'ina', 'ia'),
(57, 'Interlingue', 'ile', 'ie'),
(58, 'Inuktitut', 'iku', 'iu'),
(59, 'Inupiaq', 'ipk', 'ik'),
(60, 'Irish', 'gle', 'ga'),
(61, 'Italian', 'ita', 'it'),
(62, 'Japanese', 'jpn', 'ja'),
(63, 'Javanese', 'jav', 'jw'),
(64, 'Kalaallisut', 'kal', 'kl'),
(65, 'Kannada', 'kan', 'kn'),
(66, 'Kashmiri', 'kas', 'ks'),
(67, 'Kazakh', 'kaz', 'kk'),
(68, 'Khmer', 'khm', 'km'),
(69, 'Kikuyu', 'kik', 'ki'),
(70, 'Kinyarwanda', 'kin', 'rw'),
(71, 'Kirghiz', 'kir', 'ky'),
(72, 'Komi', 'kom', 'kv'),
(73, 'Korean', 'kor', 'ko'),
(74, 'Kuanyama', 'kua', 'kj'),
(75, 'Kurdish', 'kur', 'ku'),
(76, 'Lao', 'lao', 'lo'),
(77, 'Latin', 'lat', 'la'),
(78, 'Latvian', 'lav', 'lv'),
(79, 'Lingala', 'lin', 'ln'),
(80, 'Lithuanian', 'lit', 'lt'),
(81, 'Luxembourgish', 'ltz', 'lb'),
(82, 'Macedonian', 'mkd', 'mk'),
(83, 'Malagasy', 'mlg', 'mg'),
(84, 'Malay', 'msa', 'ms'),
(85, 'Malayalam', 'mal', 'ml'),
(86, 'Maltese', 'mlt', 'mt'),
(87, 'Manx', 'glv', 'gv'),
(88, 'Maori', 'mao', 'mi'),
(89, 'Marathi', 'mar', 'mr'),
(90, 'Marshallese', 'mah', 'mh'),
(91, 'Moldavian', 'mol', 'mo'),
(92, 'Mongolian', 'mon', 'mn'),
(93, 'Nauru', 'nau', 'na'),
(94, 'Navajo', 'nav', 'nv'),
(95, 'Ndebele, North', 'nde', 'nd'),
(96, 'Ndebele, South', 'nbl', 'nr'),
(97, 'Ndonga', 'ndo', 'ng'),
(98, 'Nepali', 'nep', 'ne'),
(99, 'Northern Sami', 'sme', 'se'),
(100, 'Norwegian', 'nor', 'no'),
(101, 'Norwegian Bokmål', 'nob', 'nb'),
(102, 'Norwegian Nynorsk', 'nno', 'nn'),
(103, 'Occitan (post 1500)', 'oci', 'oc'),
(104, 'Oriya', 'ori', 'or'),
(105, 'Oromo', 'orm', 'om'),
(106, 'Ossetian', 'oss', 'os'),
(107, 'Pali', 'pli', 'pi'),
(108, 'Panjabi', 'pan', 'pa'),
(109, 'Persian', 'fas', 'fa'),
(110, 'Polish', 'pol', 'pl'),
(111, 'Portuguese', 'por', 'pt'),
(112, 'Pushto', 'pus', 'ps'),
(113, 'Quechua', 'que', 'qu'),
(114, 'Raeto-Romance', 'roh', 'rm'),
(115, 'Romanian', 'ron', 'ro'),
(116, 'Rundi', 'run', 'rn'),
(117, 'Russian', 'rus', 'ru'),
(118, 'Samoan', 'smo', 'sm'),
(119, 'Sango', 'sag', 'sg'),
(120, 'Sanskrit', 'san', 'sa'),
(121, 'Sardinian', 'srd', 'sc'),
(122, 'Serbian', 'srp', 'sr'),
(123, 'Shona', 'sna', 'sn'),
(124, 'Sindhi', 'snd', 'sd'),
(125, 'Sinhalese', 'sin', 'si'),
(126, 'Slovak', 'slo', 'sk'),
(127, 'Slovenian', 'slv', 'sl'),
(128, 'Somali', 'som', 'so'),
(129, 'Sotho, Southern', 'sot', 'st'),
(130, 'Spanish', 'spa', 'es'),
(131, 'Sundanese', 'sun', 'su'),
(132, 'Swahili', 'swa', 'sw'),
(133, 'Swati', 'ssw', 'ss'),
(134, 'Swedish', 'swe', 'sv'),
(135, 'Tagalog', 'tgl', 'tl'),
(136, 'Tahitian', 'tah', 'ty'),
(137, 'Tajik', 'tgk', 'tg'),
(138, 'Tamil', 'tam', 'ta'),
(139, 'Tatar', 'tat', 'tt'),
(140, 'Telugu', 'tel', 'te'),
(141, 'Thai', 'tha', 'th'),
(142, 'Tibetan', 'bod', 'bo'),
(143, 'Tsonga', 'tso', 'ts'),
(144, 'Tswana', 'tsn', 'tn'),
(145, 'Turkish', 'tur', 'tr'),
(146, 'Turkmen', 'tuk', 'tk'),
(147, 'Twi', 'twi', 'tw'),
(148, 'Uighur', 'uig', 'ug'),
(149, 'Ukrainian', 'ukr', 'uk'),
(150, 'Urdu', 'urd', 'ur'),
(151, 'Uzbek', 'uzb', 'uz'),
(152, 'Vietnamese', 'vie', 'vi'),
(153, 'Volapük', 'vol', 'vo'),
(154, 'Welsh', 'wel', 'cy'),
(155, 'Welsh', 'cym', 'cy'),
(156, 'Wolof', 'wol', 'wo'),
(157, 'Xhosa', 'xho', 'xh'),
(158, 'Yiddish', 'yid', 'yi'),
(159, 'Zhuang', 'zha', 'za'),
(160, 'Zulu', 'zul', 'zu');

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_detail_tbl`
--

DROP TABLE IF EXISTS `documents_detail_tbl`;
CREATE TABLE `documents_detail_tbl` (
  `document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_document_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_language_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_user_id` int(10) UNSIGNED NOT NULL,
  `document_detail_modificationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `document_detail_status` varchar(9) NOT NULL DEFAULT 'DRAFT',
  `document_detail_translated` tinyint(1) NOT NULL DEFAULT '0',
  `document_detail_isVisible` tinyint(1) DEFAULT '1',
  `document_detail_object` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `documents_detail_tbl`
--

INSERT INTO `documents_detail_tbl` (`document_detail_id`, `document_detail_FK_document_id`, `document_detail_FK_language_id`, `document_detail_FK_user_id`, `document_detail_modificationDate`, `document_detail_status`, `document_detail_translated`, `document_detail_isVisible`, `document_detail_object`) VALUES
(39, 22, 1, 1, '2017-03-15 18:09:38', 'PUBLISHED', 1, 1, '{\"id\":\"144\",\"title\":\"Login\",\"content\":{\"__indexFields\":{},\"link\":\"internal:149\"}}'),
(40, 23, 1, 1, '2017-06-23 11:15:32', 'PUBLISHED', 1, 1, '{\"id\":\"1\",\"title\":\"Home\",\"content\":{\"__indexFields\":{},\"images\":{\"image\":[\"{\\\"id\\\":38,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_10873_6.c.5.9.jpg\\\",\\\"title\\\":\\\"snsp_dis_10873_6.c.5.9\\\",\\\"src\\\":\\\"getImage.php?id=38&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":1152}\",\"{\\\"id\\\":23,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_Carducci_FBC_CAR_ACR_1891_0023DO_02.jpg\\\",\\\"title\\\":\\\"Carducci_FBC_CAR_ACR_1891_0023DO_02\\\",\\\"src\\\":\\\"getImage.php?id=23&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1104,\\\"height\\\":642}\",\"{\\\"id\\\":22,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_Einstein_FBC_CAR_ACR_1944_0563DO_01_crop.jpg\\\",\\\"title\\\":\\\"Einstein_FBC_CAR_ACR_1944_0563DO_01_crop\\\",\\\"src\\\":\\\"getImage.php?id=22&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1325,\\\"height\\\":708}\",\"{\\\"id\\\":14,\\\"filename\\\":\\\"74a4bb23fa9ff9a205e41f760fd89543_immaginePortale1.jpg\\\",\\\"title\\\":\\\"immaginePortale1\\\",\\\"src\\\":\\\"getImage.php?id=14&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":994,\\\"height\\\":708}\",\"{\\\"id\\\":13,\\\"filename\\\":\\\"74a4bb23fa9ff9a205e41f760fd89543_immaginePortale2.jpg\\\",\\\"title\\\":\\\"immaginePortale2\\\",\\\"src\\\":\\\"getImage.php?id=13&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":3095,\\\"height\\\":2520}\",\"{\\\"id\\\":21,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_Pertini_FBC_CAR_ACR_1944_1105DO_01_crop.jpg\\\",\\\"title\\\":\\\"Pertini_FBC_CAR_ACR_1944_1105DO_01_crop\\\",\\\"src\\\":\\\"getImage.php?id=21&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1401,\\\"height\\\":708}\",\"{\\\"id\\\":32,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_10829_8.i.2.1.jpg\\\",\\\"title\\\":\\\"snsp_dis_10829_8.i.2.1\\\",\\\"src\\\":\\\"getImage.php?id=32&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1200,\\\"height\\\":869}\",\"{\\\"id\\\":26,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11105_8.p.1.9_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11105_8.p.1.9_01\\\",\\\"src\\\":\\\"getImage.php?id=26&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":797,\\\"height\\\":1129}\",\"{\\\"id\\\":33,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11106_8.p.1.10_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11106_8.p.1.10_01\\\",\\\"src\\\":\\\"getImage.php?id=33&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2224,\\\"height\\\":1718}\",\"{\\\"id\\\":34,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11107_8.p.1.11_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11107_8.p.1.11_01\\\",\\\"src\\\":\\\"getImage.php?id=34&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2357,\\\"height\\\":1198}\",\"{\\\"id\\\":35,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11110_8.p.1.14_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11110_8.p.1.14_01\\\",\\\"src\\\":\\\"getImage.php?id=35&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2374,\\\"height\\\":1730}\",\"{\\\"id\\\":37,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11114_8.p.1.17_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11114_8.p.1.17_01\\\",\\\"src\\\":\\\"getImage.php?id=37&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1803,\\\"height\\\":2549}\",\"{\\\"id\\\":36,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11115_8.p.1.18_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11115_8.p.1.18_01\\\",\\\"src\\\":\\\"getImage.php?id=36&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1170,\\\"height\\\":1584}\",\"{\\\"id\\\":39,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11125_8.p.1.25_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11125_8.p.1.25_01\\\",\\\"src\\\":\\\"getImage.php?id=39&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2388,\\\"height\\\":1780}\",\"{\\\"id\\\":40,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11129_6.a.14.jpg\\\",\\\"title\\\":\\\"snsp_dis_11129_6.a.14\\\",\\\"src\\\":\\\"getImage.php?id=40&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":960}\",\"{\\\"id\\\":4,\\\"filename\\\":\\\"6f651fd3feebe3ca34dd743603b7d260_snsp_dis_11236_7.f.2.11.jpg\\\",\\\"title\\\":\\\"snsp_dis_11236_7.f.2.11\\\",\\\"src\\\":\\\"getImage.php?id=4&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[\\\"Collezioni\\\",\\\"SNSP\\\"],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2790,\\\"height\\\":3114}\",\"{\\\"id\\\":28,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11518_9.e.5.1_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11518_9.e.5.1_01\\\",\\\"src\\\":\\\"getImage.php?id=28&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2031,\\\"height\\\":2803}\",\"{\\\"id\\\":30,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_11522_9.e.5.5_01.jpg\\\",\\\"title\\\":\\\"snsp_dis_11522_9.e.5.5_01\\\",\\\"src\\\":\\\"getImage.php?id=30&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":2287,\\\"height\\\":1620}\",\"{\\\"id\\\":41,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_12321_6.e.7.4.jpg\\\",\\\"title\\\":\\\"snsp_dis_12321_6.e.7.4\\\",\\\"src\\\":\\\"getImage.php?id=41&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":974}\",\"{\\\"id\\\":46,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_12498_6.m.2.10.jpg\\\",\\\"title\\\":\\\"snsp_dis_12498_6.m.2.10\\\",\\\"src\\\":\\\"getImage.php?id=46&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":1212}\",\"{\\\"id\\\":42,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_12523_6.n.2.14.jpg\\\",\\\"title\\\":\\\"snsp_dis_12523_6.n.2.14\\\",\\\"src\\\":\\\"getImage.php?id=42&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":828}\",\"{\\\"id\\\":43,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_12548_6.n.6.1.jpg\\\",\\\"title\\\":\\\"snsp_dis_12548_6.n.6.1\\\",\\\"src\\\":\\\"getImage.php?id=43&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":882}\",\"{\\\"id\\\":45,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_12724b_10.d.4.jpg\\\",\\\"title\\\":\\\"snsp_dis_12724b_10.d.4\\\",\\\"src\\\":\\\"getImage.php?id=45&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":949}\",\"{\\\"id\\\":44,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_12814_10.b.2.1.jpg\\\",\\\"title\\\":\\\"snsp_dis_12814_10.b.2.1\\\",\\\"src\\\":\\\"getImage.php?id=44&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1280,\\\"height\\\":1548}\",\"{\\\"id\\\":31,\\\"filename\\\":\\\"490064a868837e5b92e8d3c4bba83788_snsp_dis_13948_7.p.3.1.jpg\\\",\\\"title\\\":\\\"snsp_dis_13948_7.p.3.1\\\",\\\"src\\\":\\\"getImage.php?id=31&w=150&h=150&c=1&co=1&f=0&t=0&.jpg\\\",\\\"category\\\":[],\\\"type\\\":\\\"IMAGE\\\",\\\"author\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"copyright\\\":\\\"\\\",\\\"width\\\":1200,\\\"height\\\":572}\"]}}}'),
(47, 30, 1, 1, '2017-06-14 17:36:26', 'PUBLISHED', 1, 1, '{\"id\":\"157\",\"title\":\"metaFAD\",\"content\":{\"__indexFields\":{},\"link\":\"internal:156\"}}'),
(48, 31, 1, 1, '2017-10-16 12:38:26', 'PUBLISHED', 1, 1, '{\"id\":\"156\",\"title\":\"metaFAD\",\"content\":{\"__indexFields\":{},\"responsabile\":\"info@polodigitalenapoli.it\",\"menuVoice1\":\"Progetto\",\"menuVoice2\":\"Gruppo di lavoro\",\"menuVoice3\":\"Area riservata\",\"projectTitle\":\"Il progetto metaFAD\",\"projectText\":\"<p>Il modello <strong>metaFAD<\\/strong> &egrave; nato nell&rsquo;ambito del progetto del Polo digitale degli istituti culturali di Napoli, di cui rappresenta l&rsquo;anima tecnologica, in stretta sinergia con <strong>ICCU<\\/strong>, <strong>ICAR<\\/strong> e <strong>ICCD<\\/strong>.<\\/p>\\n<p><strong>metaFAD<\\/strong>&nbsp;&egrave; un software modulare che consente di descrivere archivi, collezioni d&rsquo;arte e biblioteche in un unico ambiente integrato, per l&rsquo;immediata fruizione attraverso il web. Una piattaforma multi-standard rilasciata con licenza open source.<\\/p>\\n<p><strong>metaFAD<\\/strong> alimenta i principali aggregatori nazionali: Internet Culturale e CulturaItalia attraverso i formati MAG e PICO; il Sistema Archivistico Nazionale attraverso i formati CAT-SAN e METS-SAN; il Sistema Informativo Generale del Catalogo attraverso il formato di scambio ICCD92.<\\/p>\\n<h4>Principali caratteristiche funzionali<\\/h4>\\n<p><strong>metaFAD<\\/strong> consente di descrivere il Patrimonio culturale sulla base di standard specifici a seconda della tipologia di materiale:<\\/p>\\n<ul>\\n<li>collezioni museali e materiale grafico secondo le normative dettate da ICCD;<\\/li>\\n<li>documenti d\'archivio sulla base delle metodologie e degli standard internazionali proposti da ICAR;<\\/li>\\n<li>materiale bibliografico e manoscritti in cooperazione applicativa con SBN e Manus.<\\/li>\\n<\\/ul>\\n<p><strong>metaFAD<\\/strong> consente di eseguire molteplici operazioni sugli oggetti digitali e generare i metadati gestionali:<\\/p>\\n<ul>\\n<li>con le funzionalit&agrave; del DAM si importano gli oggetti digitali e si generano tutti i formati necessari alla fruizione;<\\/li>\\n<li>con gli editor MAG e METS si producono automaticamente i metadati gestionali necessari ad alimentare i servizi nazionali come Internet Culturale e il Sistema Archivistico Nazionale;<\\/li>\\n<li>con il formato di scambio ICCD92 si alimenta il Sistema Generale del Catalogo.<\\/li>\\n<\\/ul>\\n<p><strong>metaFAD<\\/strong> consente di configurare le interfacce di ricerca sia per una ricerca globale su tutto il patrimonio sia per ricerche specialistiche su ciascun dominio (bibliografico, archivistico, storico-artistico).<\\/p>\\n<p><\\/p>\\n<p><strong>Per informazioni<\\/strong>: <a href=\\\"mailto:info@polodigitalenapoli.it\\\" title=\\\"info@polodigitalenapoli.it\\\">info@polodigitalenapoli.it<\\/a><\\/p>\\n<h4>Approfondimenti<\\/h4>\\n<ul>\\n<li>cfr. Giornata di presentazione di&nbsp;<a href=\\\"http:\\/\\/www.icar.beniculturali.it\\/index.php?id=248\\\" title=\\\"metaFAD. Sistema di gestione integrata dei beni culturali\\\" rel=\\\"external\\\">metaFAD. Sistema di gestione integrata dei beni culturali<\\/a>, Roma 30 marzo 2017, nel sito web <a href=\\\"http:\\/\\/www.icar.beniculturali.it\\/index.php?id=2\\\" title=\\\"ICAR\\\" rel=\\\"external\\\">ICAR<\\/a><\\/li>\\n<li>cfr. L. Cerullo,&nbsp;<a href=\\\"http:\\/\\/digitalia.sbn.it\\/article\\/view\\/1479\\/986\\\" title=\\\"Il Polo digitale degli istituti culturali di Napoli\\\" rel=\\\"external\\\">Il Polo digitale degli istituti culturali di Napoli<\\/a>, in <em>Digitalia,<\\/em> Vol. 2015, pp. 102-121<\\/li>\\n<\\/ul>\",\"groupTitle\":\"Il gruppo di lavoro\",\"groupText\":\"<h4>Archivisti &ndash; bibliotecari &ndash; storici dell&rsquo;arte<\\/h4>\\n<p>Renata Caragliano, Elli Catello, Letizia Cortini, Luciana De Maria, Marco Esposito, Loredana Gazzara, Rosa Granato, Valentina Lanzilli, Teresa Leo, Monica Mattioli, Paola Milone,&nbsp;Erika Restaino, Maria Senatore, Angela Sorrentino, Annamaria Trama, Antonella Venezia, Francesca Vittoria, Mario Quarantiello, Donatella Zampano<\\/p>\\n<h4>ICAR ICCD ICCU<\\/h4>\\n<p>Gabriella Contardi, Francesco Gandolfi, Eugenia Imperatori, Costantino Landino, Simona Lunatici, Maria Letizia Mancinelli, Cristina Mataloni, Sonja Moceri, Antonella Mul&egrave;, Maria Teresa Natale, Antonella Negri, Marco Scarbaci, Carla Scognamiglio, Maria Natalina Trivisano, Stefano Vitali<\\/p>\\n<h4>Project Manager e responsabile scientifico<\\/h4>\\n<p>Luigi Cerullo<\\/p>\\n<h4>Partner tecnologico: GruppoMeta<\\/h4>\\n<p>Emanuele Agresti, Paolo Ongaro, Alberto Raggioli, Rubino Saccoccio<\\/p>\",\"reservedTitle\":\"Area riservata\",\"reservedAreaText\":\"<p>Per ottenere maggiori informazioni sulla piattaforma open-source, sulle modalit&agrave; di rilascio del software, sulla manualistica e la documentazione tecnica di corredo, &egrave; possibile effettuare una richiesta attravero il modulo disponibile in questa pagina<\\/p>\",\"requestText\":\"<p>Grazie per la richiesta effettuata. Ricever&agrave; quanto prima informazioni sul progetto metaFAD<\\/p>\"}}'),
(49, 32, 1, 3, '2018-06-01 15:00:28', 'PUBLISHED', 1, 1, '{\"id\":\"120\",\"title\":\"Contatti\",\"content\":{\"__indexFields\":{},\"images\":{},\"text\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nunc, quod agimus; Quae quidem sapientes sequuntur duce natura tamquam videntes; Tantum dico, magis fuisse vestrum agere Epicuri diem natalem.<\\/p>\"}}'),
(50, 33, 1, 3, '2017-07-05 10:25:41', 'PUBLISHED', 1, 1, '{\"id\":\"158\",\"title\":\"Contatti\",\"content\":{\"__indexFields\":{},\"link\":\"internal:120\"}}'),
(51, 34, 1, 3, '2017-07-05 10:27:46', 'PUBLISHED', 1, 1, '{\"id\":\"4\",\"title\":\"Sezioni_portale\",\"content\":{\"__indexFields\":{}}}'),
(52, 35, 1, 3, '2017-07-05 10:30:38', 'PUBLISHED', 1, 1, '{\"id\":\"3\",\"title\":\"Footer_menu\",\"content\":{\"__indexFields\":{}}}'),
(53, 36, 1, 44, '2017-10-13 10:56:56', 'PUBLISHED', 1, 1, '{\"id\":\"55\",\"title\":\"Richiesta password\",\"content\":{\"__indexFields\":{},\"text\":\"<p>Per recuperare la password inserire l\'email associata al proprio utente. La vecchia password verr&agrave; resettata e vi sar&agrave; inviata all\'indirizzo specificato.<\\/p>\",\"confirm\":\"<p>La password &egrave; stata inviata vie email all\'indirizzo specificato. Vi consigliamo di cambiarla dopo il primo accesso.<\\/p>\"}}'),
(54, 37, 1, 44, '2017-10-13 13:10:40', 'PUBLISHED', 1, 1, '{\"id\":\"56\",\"title\":\"I miei dati\",\"content\":{\"__indexFields\":{},\"text\":\"\",\"confirm\":\"<p>I dati sono stati correttamente modificati.<\\/p>\"}}'),
(56, 39, 1, 1, '2021-05-05 13:16:39', 'PUBLISHED', 1, 1, '{\"id\":\"155\",\"title\":\"Collezioni digitali\",\"content\":{\"__indexFields\":{}}}');

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_datetime_tbl`
--

DROP TABLE IF EXISTS `documents_index_datetime_tbl`;
CREATE TABLE `documents_index_datetime_tbl` (
  `document_index_datetime_id` int(10) UNSIGNED NOT NULL,
  `document_index_datetime_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_datetime_name` varchar(70) NOT NULL,
  `document_index_datetime_value` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_date_tbl`
--

DROP TABLE IF EXISTS `documents_index_date_tbl`;
CREATE TABLE `documents_index_date_tbl` (
  `document_index_date_id` int(10) UNSIGNED NOT NULL,
  `document_index_date_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_date_name` varchar(70) NOT NULL,
  `document_index_date_value` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `documents_index_date_tbl`
--

INSERT INTO `documents_index_date_tbl` (`document_index_date_id`, `document_index_date_FK_document_detail_id`, `document_index_date_name`, `document_index_date_value`) VALUES
(39, 20, 'newsdetail_startDate', '2015-06-10'),
(40, 20, 'newsdetail_endDate', '2015-06-10'),
(41, 21, 'newsdetail_startDate', '2015-06-10'),
(42, 21, 'newsdetail_endDate', '2015-06-10'),
(43, 22, 'newsdetail_startDate', '2015-06-10'),
(44, 22, 'newsdetail_endDate', '2015-06-10'),
(45, 23, 'newsdetail_startDate', '2015-06-10'),
(46, 23, 'newsdetail_endDate', '2015-06-10'),
(47, 24, 'newsdetail_startDate', '2015-06-10'),
(48, 24, 'newsdetail_endDate', '2015-06-10'),
(49, 25, 'newsdetail_startDate', '2015-06-10'),
(50, 25, 'newsdetail_endDate', '2015-06-10');

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_fulltext_tbl`
--

DROP TABLE IF EXISTS `documents_index_fulltext_tbl`;
CREATE TABLE `documents_index_fulltext_tbl` (
  `document_index_fulltext_id` int(10) UNSIGNED NOT NULL,
  `document_index_fulltext_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_fulltext_name` varchar(70) NOT NULL,
  `document_index_fulltext_value` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `documents_index_fulltext_tbl`
--

INSERT INTO `documents_index_fulltext_tbl` (`document_index_fulltext_id`, `document_index_fulltext_FK_document_detail_id`, `document_index_fulltext_name`, `document_index_fulltext_value`) VALUES
(25, 25, 'fulltext', '10/06/2015 ## 10/06/2015 ## 0 ## aaas ## ddds ##'),
(24, 24, 'fulltext', '10/06/2015 ## 10/06/2015 ## 0 ## aaas ## ddd ##'),
(23, 23, 'fulltext', '10/06/2015 ## 10/06/2015 ## 0 ## aaa ## ddd ##'),
(22, 22, 'fulltext', '10/06/2015 ## 10/06/2015 ## 0 ## aaa ## ddd ##'),
(21, 21, 'fulltext', '10/06/2015 ## 10/06/2015 ## 0 ## aaa ## ddd ##'),
(20, 20, 'fulltext', '10/06/2015 ## 10/06/2015 ## 0 ## aaa ## ddd ##'),
(62, 40, 'fulltext', 'Home ## '),
(32, 39, 'fulltext', 'Login ## internal:149 ## '),
(117, 53, 'fulltext', 'Richiesta password ## Per recuperare la password inserire l\'email associata al proprio utente. La vecchia password verrà resettata e vi sarà inviata all\'indirizzo specificato. ## La password è stata inviata vie email all\'indirizzo specificato. Vi consigliamo di cambiarla dopo il primo accesso. ##'),
(35, 47, 'fulltext', 'metaFAD ## internal:156 ##'),
(121, 48, 'fulltext', 'metaFAD ## info@polodigitalenapoli.it ## Progetto ## Gruppo di lavoro ## Area riservata ## Il progetto metaFAD ## Il modello metaFAD è nato nell’ambito del progetto del Polo digitale degli istituti culturali di Napoli, di cui rappresenta l’anima tecnologica, in stretta sinergia con ICCU, ICAR e ICCD.\nmetaFAD è un software modulare che consente di descrivere archivi, collezioni d’arte e biblioteche in un unico ambiente integrato, per l’immediata fruizione attraverso il web. Una piattaforma multi-standard rilasciata con licenza open source.\nmetaFAD alimenta i principali aggregatori nazionali: Internet Culturale e CulturaItalia attraverso i formati MAG e PICO; il Sistema Archivistico Nazionale attraverso i formati CAT-SAN e METS-SAN; il Sistema Informativo Generale del Catalogo attraverso il formato di scambio ICCD92.\nPrincipali caratteristiche funzionali\nmetaFAD consente di descrivere il Patrimonio culturale sulla base di standard specifici a seconda della tipologia di materiale:\n\ncollezioni museali e materiale grafico secondo le normative dettate da ICCD;\ndocumenti d\'archivio sulla base delle metodologie e degli standard internazionali proposti da ICAR;\nmateriale bibliografico e manoscritti in cooperazione applicativa con SBN e Manus.\n\nmetaFAD consente di eseguire molteplici operazioni sugli oggetti digitali e generare i metadati gestionali:\n\ncon le funzionalità del DAM si importano gli oggetti digitali e si generano tutti i formati necessari alla fruizione;\ncon gli editor MAG e METS si producono automaticamente i metadati gestionali necessari ad alimentare i servizi nazionali come Internet Culturale e il Sistema Archivistico Nazionale;\ncon il formato di scambio ICCD92 si alimenta il Sistema Generale del Catalogo.\n\nmetaFAD consente di configurare le interfacce di ricerca sia per una ricerca globale su tutto il patrimonio sia per ricerche specialistiche su ciascun dominio (bibliografico, archivistico, storico-artistico).\n\nPer informazioni: info@polodigitalenapoli.it\nApprofondimenti\n\ncfr. Giornata di presentazione di metaFAD. Sistema di gestione integrata dei beni culturali, Roma 30 marzo 2017, nel sito web ICAR\ncfr. L. Cerullo, Il Polo digitale degli istituti culturali di Napoli, in Digitalia, Vol. 2015, pp. 102-121 ## Il gruppo di lavoro ## Archivisti – bibliotecari – storici dell’arte\nRenata Caragliano, Elli Catello, Letizia Cortini, Luciana De Maria, Marco Esposito, Loredana Gazzara, Rosa Granato, Valentina Lanzilli, Teresa Leo, Monica Mattioli, Paola Milone, Erika Restaino, Maria Senatore, Angela Sorrentino, Annamaria Trama, Antonella Venezia, Francesca Vittoria, Mario Quarantiello, Donatella Zampano\nICAR ICCD ICCU\nGabriella Contardi, Francesco Gandolfi, Eugenia Imperatori, Costantino Landino, Simona Lunatici, Maria Letizia Mancinelli, Cristina Mataloni, Sonja Moceri, Antonella Mulè, Maria Teresa Natale, Antonella Negri, Marco Scarbaci, Carla Scognamiglio, Maria Natalina Trivisano, Stefano Vitali\nProject Manager e responsabile scientifico\nLuigi Cerullo\nPartner tecnologico: GruppoMeta\nEmanuele Agresti, Paolo Ongaro, Alberto Raggioli, Rubino Saccoccio ## Area riservata ## Per ottenere maggiori informazioni sulla piattaforma open-source, sulle modalità di rilascio del software, sulla manualistica e la documentazione tecnica di corredo, è possibile effettuare una richiesta attravero il modulo disponibile in questa pagina ## Grazie per la richiesta effettuata. Riceverà quanto prima informazioni sul progetto metaFAD ## '),
(102, 50, 'fulltext', 'Contatti ## internal:120 ##'),
(103, 51, 'fulltext', 'Sezioni_portale ##'),
(104, 52, 'fulltext', 'Footer_menu ##'),
(122, 49, 'fulltext', 'Contatti ## Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nunc, quod agimus; Quae quidem sapientes sequuntur duce natura tamquam videntes; Tantum dico, magis fuisse vestrum agere Epicuri diem natalem. ## '),
(118, 54, 'fulltext', 'I miei dati ## I dati sono stati correttamente modificati. ##'),
(124, 56, 'fulltext', 'Collezioni digitali ## ');

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_int_tbl`
--

DROP TABLE IF EXISTS `documents_index_int_tbl`;
CREATE TABLE `documents_index_int_tbl` (
  `document_index_int_id` int(10) UNSIGNED NOT NULL,
  `document_index_int_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_int_name` varchar(70) NOT NULL,
  `document_index_int_value` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `documents_index_int_tbl`
--

INSERT INTO `documents_index_int_tbl` (`document_index_int_id`, `document_index_int_FK_document_detail_id`, `document_index_int_name`, `document_index_int_value`) VALUES
(39, 20, 'newsdetail_inHome', 0),
(40, 20, 'year', 2015),
(41, 21, 'newsdetail_inHome', 0),
(42, 21, 'year', 2015),
(43, 22, 'newsdetail_inHome', 0),
(44, 22, 'year', 2015),
(45, 23, 'newsdetail_inHome', 0),
(46, 23, 'year', 2015),
(47, 24, 'newsdetail_inHome', 0),
(48, 24, 'year', 2015),
(49, 25, 'newsdetail_inHome', 0),
(50, 25, 'year', 2015),
(69, 39, 'id', 144),
(78, 40, 'id', 1),
(88, 47, 'id', 157),
(91, 50, 'id', 158),
(92, 51, 'id', 4),
(93, 52, 'id', 3),
(107, 53, 'id', 55),
(108, 54, 'id', 56),
(111, 48, 'id', 156),
(115, 49, 'id', 120),
(171, 56, 'id', 155);

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_text_tbl`
--

DROP TABLE IF EXISTS `documents_index_text_tbl`;
CREATE TABLE `documents_index_text_tbl` (
  `document_index_text_id` int(10) UNSIGNED NOT NULL,
  `document_index_text_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_text_name` varchar(70) NOT NULL,
  `document_index_text_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `documents_index_text_tbl`
--

INSERT INTO `documents_index_text_tbl` (`document_index_text_id`, `document_index_text_FK_document_detail_id`, `document_index_text_name`, `document_index_text_value`) VALUES
(84, 20, 'newsdetail_title', 'aa'),
(85, 20, 'newsdetail_place', ''),
(86, 20, 'newsdetail_bodyShort', 'aaa'),
(87, 20, 'newsdetail_body', 'ddd'),
(88, 20, 'newsdetail_body,newsdetail_bodyShort', 'dddaaa'),
(89, 21, 'newsdetail_title', 'aa'),
(90, 21, 'newsdetail_bodyShort', 'aaa'),
(91, 21, 'newsdetail_body', 'ddd'),
(92, 21, 'newsdetail_body,newsdetail_bodyShort', 'dddaaa'),
(93, 22, 'newsdetail_title', 'aa'),
(94, 22, 'newsdetail_bodyShort', 'aaa'),
(95, 22, 'newsdetail_body', 'ddd'),
(96, 22, 'newsdetail_body,newsdetail_bodyShort', 'dddaaa'),
(97, 23, 'newsdetail_title', 'aa'),
(98, 23, 'newsdetail_bodyShort', 'aaa'),
(99, 23, 'newsdetail_body', 'ddd'),
(100, 23, 'newsdetail_body,newsdetail_bodyShort', 'dddaaa'),
(101, 24, 'newsdetail_title', 'aa'),
(102, 24, 'newsdetail_bodyShort', 'aaas'),
(103, 24, 'newsdetail_body', 'ddd'),
(104, 24, 'newsdetail_body,newsdetail_bodyShort', 'dddaaas'),
(105, 25, 'newsdetail_title', 'aa'),
(106, 25, 'newsdetail_bodyShort', 'aaas'),
(107, 25, 'newsdetail_body', 'ddds'),
(108, 25, 'newsdetail_body,newsdetail_bodyShort', 'dddsaaas');

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_time_tbl`
--

DROP TABLE IF EXISTS `documents_index_time_tbl`;
CREATE TABLE `documents_index_time_tbl` (
  `document_index_time_id` int(10) UNSIGNED NOT NULL,
  `document_index_time_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_time_name` varchar(70) NOT NULL,
  `document_index_time_value` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_tbl`
--

DROP TABLE IF EXISTS `documents_tbl`;
CREATE TABLE `documents_tbl` (
  `document_id` int(10) UNSIGNED NOT NULL,
  `document_type` varchar(255) DEFAULT NULL,
  `document_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `document_FK_site_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `documents_tbl`
--

INSERT INTO `documents_tbl` (`document_id`, `document_type`, `document_creationDate`, `document_FK_site_id`) VALUES
(8, 'museoweb.modules.news', '2015-06-25 15:36:47', NULL),
(22, 'glizycms.content', '2016-11-14 14:22:05', NULL),
(23, 'glizycms.content', '2016-11-16 15:51:33', NULL),
(30, 'glizycms.content', '2017-06-14 17:36:26', NULL),
(31, 'glizycms.content', '2017-06-14 17:36:55', NULL),
(32, 'glizycms.content', '2017-07-05 10:25:20', NULL),
(33, 'glizycms.content', '2017-07-05 10:25:41', NULL),
(34, 'glizycms.content', '2017-07-05 10:27:46', NULL),
(35, 'glizycms.content', '2017-07-05 10:30:38', NULL),
(36, 'glizycms.content', '2017-10-13 10:56:56', NULL),
(37, 'glizycms.content', '2017-10-13 13:10:40', NULL),
(39, 'pinaxcms.content', '2021-04-29 11:37:35', NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `ecommordersitems_tbl`
--

DROP TABLE IF EXISTS `ecommordersitems_tbl`;
CREATE TABLE `ecommordersitems_tbl` (
  `orderitem_id` int(10) UNSIGNED NOT NULL,
  `orderitem_FK_order_id` int(10) UNSIGNED NOT NULL,
  `orderitem_price` decimal(10,2) NOT NULL,
  `orderitem_code` varchar(255) NOT NULL,
  `orderitem_FK_license_id` int(10) DEFAULT '1',
  `orderitem_downloads` int(2) NOT NULL DEFAULT '0',
  `orderitem_title` varchar(255) NOT NULL DEFAULT '',
  `orderitem_url` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ecommorders_tbl`
--

DROP TABLE IF EXISTS `ecommorders_tbl`;
CREATE TABLE `ecommorders_tbl` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `order_code` varchar(50) NOT NULL,
  `order_date` datetime NOT NULL,
  `order_state` enum('open','completed') NOT NULL,
  `order_FK_user_id` int(10) UNSIGNED NOT NULL,
  `order_transactionCode` varchar(50) DEFAULT NULL,
  `order_bankAnswer` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `exif_tbl`
--

DROP TABLE IF EXISTS `exif_tbl`;
CREATE TABLE `exif_tbl` (
  `exif_id` int(10) UNSIGNED NOT NULL,
  `exif_FK_media_id` int(11) NOT NULL DEFAULT '0',
  `exif_imageWidth` int(11) DEFAULT NULL,
  `exif_imageHeight` int(11) DEFAULT NULL,
  `exif_make` varchar(255) DEFAULT NULL,
  `exif_model` varchar(255) DEFAULT NULL,
  `exif_exposureTime` varchar(255) DEFAULT NULL,
  `exif_fNumber` varchar(255) DEFAULT NULL,
  `exif_exposureProgram` int(11) DEFAULT NULL,
  `exif_ISOSpeedRatings` int(11) DEFAULT NULL,
  `exif_dateTimeOriginal` varchar(50) DEFAULT NULL,
  `exif_dateTimeDigitized` varchar(50) DEFAULT NULL,
  `exif_GPSCoords` varchar(255) DEFAULT NULL,
  `exif_GPSTimeStamp` varchar(255) DEFAULT NULL,
  `exif_data` text,
  `exif_resolution` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `iccd_theasaurs_tbl`
--

DROP TABLE IF EXISTS `iccd_theasaurs_tbl`;
CREATE TABLE `iccd_theasaurs_tbl` (
  `iccd_theasaurs_id` int(11) NOT NULL,
  `iccd_theasaurs_code` varchar(255) DEFAULT NULL,
  `iccd_theasaurs_level` varchar(10) DEFAULT NULL,
  `iccd_theasaurs_key` varchar(255) DEFAULT NULL,
  `iccd_theasaurs_value` text,
  `iccd_theasaurs_module` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `joins_tbl`
--

DROP TABLE IF EXISTS `joins_tbl`;
CREATE TABLE `joins_tbl` (
  `join_id` int(1) UNSIGNED NOT NULL,
  `join_FK_source_id` int(10) UNSIGNED NOT NULL,
  `join_FK_dest_id` int(10) UNSIGNED NOT NULL,
  `join_objectName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `joins_tbl`
--

INSERT INTO `joins_tbl` (`join_id`, `join_FK_source_id`, `join_FK_dest_id`, `join_objectName`) VALUES
(2, 2, 4, 'roles2usergroups'),
(10, 1, 1, 'roles2usergroups');

-- --------------------------------------------------------

--
-- Struttura della tabella `languages_tbl`
--

DROP TABLE IF EXISTS `languages_tbl`;
CREATE TABLE `languages_tbl` (
  `language_id` int(10) UNSIGNED NOT NULL,
  `language_name` varchar(100) NOT NULL DEFAULT '',
  `language_code` varchar(10) NOT NULL DEFAULT '',
  `language_FK_country_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `language_isDefault` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `language_order` int(4) UNSIGNED NOT NULL DEFAULT '0',
  `language_isVisible` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `languages_tbl`
--

INSERT INTO `languages_tbl` (`language_id`, `language_name`, `language_code`, `language_FK_country_id`, `language_isDefault`, `language_order`, `language_isVisible`) VALUES
(1, 'Italiano', 'it', 61, 1, 1, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `massiveimporter_mappings_tbl`
--

DROP TABLE IF EXISTS `massiveimporter_mappings_tbl`;
CREATE TABLE `massiveimporter_mappings_tbl` (
  `massiveimporter_mapping_id` int(10) UNSIGNED NOT NULL,
  `massiveimporter_mapping_name` varchar(255) DEFAULT NULL,
  `massiveimporter_mapping_moduleid` varchar(100) DEFAULT NULL,
  `massiveimporter_mapping_heading` text,
  `massiveimporter_mapping_mapping` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `mediadetails_tbl`
--

DROP TABLE IF EXISTS `mediadetails_tbl`;
CREATE TABLE `mediadetails_tbl` (
  `mediadetail_id` int(10) UNSIGNED NOT NULL,
  `mediadetail_FK_media_id` int(10) UNSIGNED NOT NULL,
  `media_FK_language_id` int(10) UNSIGNED NOT NULL,
  `media_FK_user_id` int(10) UNSIGNED NOT NULL,
  `media_modificationDate` datetime DEFAULT '0000-00-00 00:00:00',
  `media_title` varchar(255) NOT NULL DEFAULT '',
  `media_category` varchar(255) DEFAULT '',
  `media_date` varchar(100) DEFAULT NULL,
  `media_copyright` varchar(255) DEFAULT NULL,
  `media_description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `media_tbl`
--

DROP TABLE IF EXISTS `media_tbl`;
CREATE TABLE `media_tbl` (
  `media_id` int(10) UNSIGNED NOT NULL,
  `media_FK_site_id` int(10) UNSIGNED DEFAULT NULL,
  `media_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `media_fileName` varchar(255) NOT NULL DEFAULT '',
  `media_size` int(4) UNSIGNED NOT NULL DEFAULT '0',
  `media_type` enum('IMAGE','OFFICE','PDF','ARCHIVE','FLASH','AUDIO','VIDEO','OTHER') NOT NULL DEFAULT 'IMAGE',
  `media_author` varchar(255) DEFAULT '',
  `media_originalFileName` varchar(255) NOT NULL DEFAULT '',
  `media_zoom` tinyint(1) DEFAULT '0',
  `media_download` int(10) NOT NULL DEFAULT '0',
  `media_watermark` tinyint(1) NOT NULL DEFAULT '0',
  `media_allowDownload` tinyint(1) NOT NULL DEFAULT '1',
  `media_thumbFileName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `menudetails_tbl`
--

DROP TABLE IF EXISTS `menudetails_tbl`;
CREATE TABLE `menudetails_tbl` (
  `menudetail_id` int(10) UNSIGNED NOT NULL,
  `menudetail_FK_menu_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `menudetail_FK_language_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `menudetail_title` text,
  `menudetail_keywords` text,
  `menudetail_description` text,
  `menudetail_subject` text,
  `menudetail_creator` text,
  `menudetail_publisher` text,
  `menudetail_contributor` text,
  `menudetail_type` text,
  `menudetail_identifier` text,
  `menudetail_source` text,
  `menudetail_relation` text,
  `menudetail_coverage` text,
  `menudetail_isVisible` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `menudetail_titleLink` varchar(255) DEFAULT '',
  `menudetail_linkDescription` varchar(255) DEFAULT '',
  `menudetail_url` text,
  `menudetail_seoTitle` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `menudetails_tbl`
--

INSERT INTO `menudetails_tbl` (`menudetail_id`, `menudetail_FK_menu_id`, `menudetail_FK_language_id`, `menudetail_title`, `menudetail_keywords`, `menudetail_description`, `menudetail_subject`, `menudetail_creator`, `menudetail_publisher`, `menudetail_contributor`, `menudetail_type`, `menudetail_identifier`, `menudetail_source`, `menudetail_relation`, `menudetail_coverage`, `menudetail_isVisible`, `menudetail_titleLink`, `menudetail_linkDescription`, `menudetail_url`, `menudetail_seoTitle`) VALUES
(1, 1, 1, 'Home', 'parole chiave', 'descrizione', '', '', '', '', '', '', '', '', '', 1, 'metaFAD', '', NULL, NULL),
(14, 14, 1, 'Strumenti', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(17, 17, 1, 'Utilità', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(26, 26, 1, 'Guida', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', NULL, NULL),
(27, 27, 1, 'Mappa del sito', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', NULL, NULL),
(29, 29, 1, 'Ricerca', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(101, 54, 1, 'Logout', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(103, 55, 1, 'Richiesta password', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(105, 56, 1, 'I miei dati', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(296, 120, 1, 'Contatti', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(434, 2, 1, 'Metanavigazione', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(438, 3, 1, 'Footer_menu', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(442, 4, 1, 'Sezioni_portale', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(446, 5, 1, 'Strumenti', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(450, 135, 1, 'Disclaimer', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', NULL, NULL),
(454, 136, 1, 'Crediti', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', NULL, NULL),
(458, 137, 1, 'Home', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(467, 140, 1, 'Ricerca Avanzata', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(468, 141, 1, 'Viewer', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(471, 144, 1, 'Login', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(472, 145, 1, 'Carrello', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(474, 147, 1, 'Richieste', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(475, 148, 1, 'Registrazione', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(476, 149, 1, 'Login', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(477, 150, 1, 'Servizi', '', '', '', '', '', '', '', '', '', '', '', 1, '', '', NULL, NULL),
(480, 153, 1, 'Popup carrello', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(481, 154, 1, 'Dettaglio popup', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(482, 155, 1, 'Collezioni digitali', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(483, 156, 1, 'metaFAD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(484, 157, 1, 'metaFAD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL),
(485, 158, 1, 'Contatti', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `menus_tbl`
--

DROP TABLE IF EXISTS `menus_tbl`;
CREATE TABLE `menus_tbl` (
  `menu_id` int(10) UNSIGNED NOT NULL,
  `menu_FK_site_id` int(10) UNSIGNED DEFAULT NULL,
  `menu_parentId` int(10) UNSIGNED DEFAULT '0',
  `menu_pageType` varchar(100) NOT NULL DEFAULT '',
  `menu_order` int(4) UNSIGNED DEFAULT '0',
  `menu_hasPreview` tinyint(1) UNSIGNED DEFAULT '1',
  `menu_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `menu_modificationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `menu_type` enum('HOMEPAGE','PAGE','SYSTEM') NOT NULL DEFAULT 'PAGE',
  `menu_url` varchar(255) DEFAULT '',
  `menu_isLocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `menu_hasComment` tinyint(1) NOT NULL DEFAULT '0',
  `menu_printPdf` tinyint(1) NOT NULL DEFAULT '0',
  `menu_extendsPermissions` tinyint(1) NOT NULL DEFAULT '0',
  `menu_cssClass` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `menus_tbl`
--

INSERT INTO `menus_tbl` (`menu_id`, `menu_FK_site_id`, `menu_parentId`, `menu_pageType`, `menu_order`, `menu_hasPreview`, `menu_creationDate`, `menu_modificationDate`, `menu_type`, `menu_url`, `menu_isLocked`, `menu_hasComment`, `menu_printPdf`, `menu_extendsPermissions`, `menu_cssClass`) VALUES
(1, NULL, 0, 'Home', 1, 1, '2016-10-11 00:00:00', '2017-06-23 11:15:32', 'HOMEPAGE', '', 0, 0, 0, 0, ''),
(2, NULL, 1, 'Empty', 0, 1, '2015-04-08 11:55:28', '2015-04-08 11:55:28', 'SYSTEM', '', 0, 0, 0, 0, NULL),
(3, NULL, 1, 'Empty', 1, 1, '2015-04-08 11:55:28', '2017-07-05 10:30:38', 'SYSTEM', '', 0, 0, 0, 0, NULL),
(4, NULL, 1, 'Empty', 2, 1, '2015-04-08 11:55:28', '2017-07-05 10:27:46', 'SYSTEM', '', 0, 0, 0, 0, NULL),
(5, NULL, 1, 'Empty', 3, 1, '2015-04-08 11:55:28', '2015-04-08 11:55:28', 'SYSTEM', '', 0, 0, 0, 0, NULL),
(26, NULL, 4, 'Page', 0, 1, '2005-10-10 00:00:00', '2009-07-08 00:00:00', 'PAGE', '', 0, 0, 0, 0, NULL),
(27, NULL, 4, 'SiteMap', 1, 1, '2005-11-01 00:00:00', '2009-07-08 00:00:00', 'PAGE', '', 0, 0, 0, 0, NULL),
(29, NULL, 4, 'Search', 2, 1, '2005-11-07 00:00:00', '2009-07-08 00:00:00', 'PAGE', '', 0, 0, 0, 0, NULL),
(54, NULL, 4, 'Logout', 3, 1, '2006-05-19 00:00:00', '2006-05-19 00:00:00', 'SYSTEM', '', 0, 0, 0, 0, NULL),
(55, NULL, 4, 'LostPassword', 4, 1, '2006-05-19 00:00:00', '2017-10-13 10:56:56', 'SYSTEM', '', 0, 0, 0, 0, NULL),
(56, NULL, 4, 'UserDetails', 5, 1, '2006-05-19 00:00:00', '2017-10-13 13:10:40', 'SYSTEM', '', 1, 0, 0, 0, NULL),
(120, NULL, 4, 'Page', 6, 1, '2009-10-06 00:00:00', '2018-06-01 15:00:28', 'PAGE', '', 0, 0, 0, 0, NULL),
(135, NULL, 3, 'Alias', 0, 1, '2015-04-08 11:55:28', '2015-04-08 11:55:28', 'PAGE', 'alias:internal:15', 0, 0, 0, 0, NULL),
(136, NULL, 3, 'Alias', 1, 1, '2015-04-08 11:55:28', '2015-04-08 11:55:28', 'PAGE', 'alias:internal:119', 0, 0, 0, 0, NULL),
(137, NULL, 2, 'Alias', 0, 1, '2015-04-08 00:00:00', '2015-04-08 11:55:29', 'PAGE', 'it/1/home?unsetInstitutes=true', 0, 0, 0, 0, 'home'),
(140, NULL, 4, 'AdvancedSearch', 7, 1, '2016-09-05 10:11:09', '2016-09-05 10:11:09', 'PAGE', '', 0, 0, 0, 0, ''),
(141, NULL, 4, 'Viewer', 8, 1, '2016-09-12 17:05:08', '2016-09-12 17:05:08', 'PAGE', '', 0, 0, 0, 0, ''),
(144, NULL, 2, 'Alias', 1, 1, '2016-11-14 00:00:00', '2017-03-15 18:09:39', 'PAGE', '#plogin', 0, 0, 0, 0, 'login'),
(145, NULL, 4, 'museoweb.modules.ecommerce.views.FrontEnd', 9, 1, '2017-01-16 18:13:40', '2017-01-16 18:13:40', 'PAGE', '', 0, 0, 0, 0, ''),
(147, 0, 4, 'Requests', 11, 1, '2017-03-15 18:06:35', '2017-03-15 18:06:35', 'PAGE', '', 0, 0, 0, 0, ''),
(148, 0, 4, 'Registration', 12, 1, '2017-03-15 18:07:22', '2017-03-15 18:07:22', 'PAGE', '', 0, 0, 0, 0, ''),
(149, 0, 4, 'Login', 13, 1, '2017-03-15 18:09:31', '2017-03-15 18:09:31', 'PAGE', '', 0, 0, 0, 0, ''),
(150, 0, 4, 'Services', 14, 1, '2017-03-17 15:05:04', '2017-03-17 15:05:04', 'PAGE', '', 0, 0, 0, 0, ''),
(153, NULL, 4, 'CarrelloPopup', 15, 1, '2017-03-22 12:11:16', '2017-03-22 12:11:16', 'PAGE', '', 0, 0, 0, 0, ''),
(154, NULL, 4, 'DetailPopup', 16, 1, '2017-03-28 14:55:44', '2017-03-28 14:55:44', 'PAGE', '', 0, 0, 0, 0, ''),
(155, NULL, 1, 'metafad.modules.collections.views.FrontEnd', 4, 1, '2017-06-13 00:00:00', '2021-05-05 13:16:39', 'PAGE', '', 0, 0, 0, 0, ''),
(156, NULL, 4, 'Metafad', 18, 1, '2017-06-14 17:36:07', '2017-10-16 12:38:26', 'PAGE', '', 0, 0, 0, 0, ''),
(157, NULL, 2, 'Alias', 4, 1, '2017-06-14 00:00:00', '2017-06-14 17:36:26', 'PAGE', 'alias:internal:156', 0, 0, 0, 0, 'metafad'),
(158, NULL, 3, 'Alias', 3, 1, '2017-07-05 10:23:45', '2017-07-05 10:25:41', 'PAGE', 'alias:internal:120', 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Struttura della tabella `niso_tbl`
--

DROP TABLE IF EXISTS `niso_tbl`;
CREATE TABLE `niso_tbl` (
  `niso_id` int(10) UNSIGNED NOT NULL,
  `niso_FK_media_id` int(11) NOT NULL DEFAULT '0',
  `niso_imagelength` int(11) DEFAULT NULL,
  `niso_imagewidth` int(11) DEFAULT NULL,
  `niso_source_xdimension` double DEFAULT NULL,
  `niso_source_ydimension` double DEFAULT NULL,
  `niso_samplingfrequencyunit` int(11) DEFAULT '1',
  `niso_samplingfrequencyplane` int(11) DEFAULT NULL,
  `niso_ysamplingfrequency` int(11) DEFAULT NULL,
  `niso_xsamplingfrequency` int(11) DEFAULT NULL,
  `niso_photometricinterpretation` varchar(255) DEFAULT NULL,
  `niso_bitpersample` varchar(255) DEFAULT NULL,
  `niso_name` varchar(255) DEFAULT NULL,
  `niso_mime` varchar(255) DEFAULT NULL,
  `niso_compression` varchar(255) DEFAULT NULL,
  `niso_source_type` varchar(255) DEFAULT NULL,
  `niso_scanningagency` varchar(255) DEFAULT NULL,
  `niso_devicesource` varchar(255) DEFAULT NULL,
  `niso_scanningsystem` varchar(255) DEFAULT NULL,
  `niso_scanner_manufacturer` varchar(255) DEFAULT NULL,
  `niso_scanner_model` varchar(255) DEFAULT NULL,
  `niso_capture_software` varchar(255) DEFAULT NULL,
  `niso_targetType` varchar(255) DEFAULT NULL,
  `niso_targetID` varchar(255) DEFAULT NULL,
  `niso_imageData` varchar(255) DEFAULT NULL,
  `niso_performanceData` varchar(255) DEFAULT NULL,
  `niso_profiles` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `niso_tbl`
--

INSERT INTO `niso_tbl` (`niso_id`, `niso_FK_media_id`, `niso_imagelength`, `niso_imagewidth`, `niso_source_xdimension`, `niso_source_ydimension`, `niso_samplingfrequencyunit`, `niso_samplingfrequencyplane`, `niso_ysamplingfrequency`, `niso_xsamplingfrequency`, `niso_photometricinterpretation`, `niso_bitpersample`, `niso_name`, `niso_mime`, `niso_compression`, `niso_source_type`, `niso_scanningagency`, `niso_devicesource`, `niso_scanningsystem`, `niso_scanner_manufacturer`, `niso_scanner_model`, `niso_capture_software`, `niso_targetType`, `niso_targetID`, `niso_imageData`, `niso_performanceData`, `niso_profiles`) VALUES
(1, 5, 1055, 1850, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 'png', 'image/png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `picoqueues_tbl`
--

DROP TABLE IF EXISTS `picoqueues_tbl`;
CREATE TABLE `picoqueues_tbl` (
  `picoqueue_id` int(11) UNSIGNED NOT NULL,
  `picoqueue_date` datetime NOT NULL,
  `picoqueue_action` enum('insert','update','delete') NOT NULL,
  `picoqueue_identifier` varchar(255) NOT NULL,
  `picoqueue_recordId` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `picoqueue_recordModule` varchar(255) NOT NULL,
  `picoqueue_processed` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `registry_tbl`
--

DROP TABLE IF EXISTS `registry_tbl`;
CREATE TABLE `registry_tbl` (
  `registry_id` int(11) NOT NULL,
  `registry_path` varchar(255) NOT NULL DEFAULT '',
  `registry_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `registry_tbl`
--

INSERT INTO `registry_tbl` (`registry_id`, `registry_path`, `registry_value`) VALUES
(1, 'museoweb/templateName', 'Default'),
(3, 'museoweb/siteProp/it', 'a:10:{s:5:\"title\";s:7:\"metaFAD\";s:7:\"address\";s:167:\"<p>Ut nemo dubitet, eorum omnia officia quo spectare</p>\n<p>quid sequi, quid fugere debeant? Si stante, hoc natura videlicet vult, salvam esse se, quod concedimus;</p>\";s:9:\"copyright\";s:14:\"copyright 2018\";s:9:\"slideShow\";s:1:\"5\";s:9:\"analytics\";s:0:\"\";s:7:\"addthis\";i:0;s:8:\"facebook\";s:24:\"https://www.facebook.com\";s:7:\"twitter\";s:23:\"https://www.twitter.com\";s:9:\"instagram\";s:25:\"https://www.instagram.com\";s:7:\"youtube\";s:23:\"https://www.youtube.com\";}'),
(10, 'museoweb/templateValues/Default', '{\"0\":{\"footer\":{},\"headerLogo\":\"\"}}');

-- --------------------------------------------------------

--
-- Struttura della tabella `roles_tbl`
--

DROP TABLE IF EXISTS `roles_tbl`;
CREATE TABLE `roles_tbl` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `role_name` varchar(100) NOT NULL DEFAULT '',
  `role_permissions` text NOT NULL,
  `role_active` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `roles_tbl`
--

INSERT INTO `roles_tbl` (`role_id`, `role_name`, `role_permissions`, `role_active`) VALUES
(1, 'Amministratori', 'a:12:{s:4:\"home\";a:1:{s:3:\"all\";s:1:\"1\";}s:12:\"mediaarchive\";a:1:{s:3:\"all\";s:1:\"1\";}s:11:\"collections\";a:1:{s:3:\"all\";s:1:\"1\";}s:20:\"institutesmanagement\";a:1:{s:3:\"all\";s:1:\"1\";}s:21:\"pinaxcms_contentsedit\";a:1:{s:3:\"all\";s:1:\"1\";}s:18:\"pinaxcms_languages\";a:1:{s:3:\"all\";s:1:\"1\";}s:21:\"pinaxcms_siteproperty\";a:1:{s:3:\"all\";s:1:\"1\";}s:23:\"pinaxcms_templateselect\";a:1:{s:3:\"all\";s:1:\"1\";}s:17:\"usermanager_alias\";a:1:{s:3:\"all\";s:1:\"1\";}s:11:\"usermanager\";a:1:{s:3:\"all\";s:1:\"1\";}s:12:\"groupmanager\";a:1:{s:3:\"all\";s:1:\"1\";}s:11:\"rolemanager\";a:1:{s:3:\"all\";s:1:\"1\";}}', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_datetime_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_datetime_tbl`;
CREATE TABLE `simple_documents_index_datetime_tbl` (
  `simple_document_index_datetime_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_datetime_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_datetime_name` varchar(70) NOT NULL,
  `simple_document_index_datetime_value` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_date_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_date_tbl`;
CREATE TABLE `simple_documents_index_date_tbl` (
  `simple_document_index_date_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_date_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_date_name` varchar(70) NOT NULL,
  `simple_document_index_date_value` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_fulltext_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_fulltext_tbl`;
CREATE TABLE `simple_documents_index_fulltext_tbl` (
  `simple_document_index_fulltext_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_fulltext_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_fulltext_name` varchar(70) NOT NULL,
  `simple_document_index_fulltext_value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_int_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_int_tbl`;
CREATE TABLE `simple_documents_index_int_tbl` (
  `simple_document_index_int_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_int_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_int_name` varchar(70) NOT NULL,
  `simple_document_index_int_value` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_text_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_text_tbl`;
CREATE TABLE `simple_documents_index_text_tbl` (
  `simple_document_index_text_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_text_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_text_name` varchar(70) NOT NULL,
  `simple_document_index_text_value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_index_time_tbl`
--

DROP TABLE IF EXISTS `simple_documents_index_time_tbl`;
CREATE TABLE `simple_documents_index_time_tbl` (
  `simple_document_index_time_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_time_FK_simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_index_time_name` varchar(70) NOT NULL,
  `simple_document_index_time_value` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `simple_documents_tbl`
--

DROP TABLE IF EXISTS `simple_documents_tbl`;
CREATE TABLE `simple_documents_tbl` (
  `simple_document_id` int(10) UNSIGNED NOT NULL,
  `simple_document_FK_site_id` int(10) UNSIGNED DEFAULT NULL,
  `simple_document_type` varchar(255) NOT NULL,
  `simple_document_object` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `speakingurls_tbl`
--

DROP TABLE IF EXISTS `speakingurls_tbl`;
CREATE TABLE `speakingurls_tbl` (
  `speakingurl_id` int(11) NOT NULL,
  `speakingurl_FK_language_id` int(11) NOT NULL,
  `speakingurl_FK` int(11) NOT NULL,
  `speakingurl_type` varchar(255) NOT NULL,
  `speakingurl_value` varchar(255) NOT NULL,
  `speakingurl_option` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `usergroups_tbl`
--

DROP TABLE IF EXISTS `usergroups_tbl`;
CREATE TABLE `usergroups_tbl` (
  `usergroup_id` int(11) NOT NULL,
  `usergroup_name` varchar(50) NOT NULL DEFAULT '',
  `usergroup_backEndAccess` tinyint(1) NOT NULL DEFAULT '0',
  `usergroup_FK_site_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `usergroups_tbl`
--

INSERT INTO `usergroups_tbl` (`usergroup_id`, `usergroup_name`, `usergroup_backEndAccess`, `usergroup_FK_site_id`) VALUES
(1, 'Amministratori', 1, NULL),
(2, 'Supervisiore', 1, NULL),
(3, 'Redattori', 1, NULL),
(4, 'Utenti', 0, NULL),
(5, 'Direttore Museo', 0, NULL),
(6, 'Responsabile catalogazione', 0, NULL),
(7, 'Altro', 0, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `userlogs_tbl`
--

DROP TABLE IF EXISTS `userlogs_tbl`;
CREATE TABLE `userlogs_tbl` (
  `userlog_id` int(10) UNSIGNED NOT NULL,
  `userlog_FK_user_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `userlog_session` varchar(50) NOT NULL DEFAULT '',
  `userlog_ip` varchar(50) NOT NULL DEFAULT '',
  `userlog_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `userlog_lastAction` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `users_tbl`
--

DROP TABLE IF EXISTS `users_tbl`;
CREATE TABLE `users_tbl` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_FK_usergroup_id` int(10) UNSIGNED NOT NULL DEFAULT '2',
  `user_FK_site_id` int(10) UNSIGNED DEFAULT NULL,
  `user_dateCreation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_isActive` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `user_loginId` varchar(100) NOT NULL DEFAULT '',
  `user_password` varchar(100) NOT NULL DEFAULT '',
  `user_firstName` varchar(100) NOT NULL DEFAULT '',
  `user_lastName` varchar(100) NOT NULL DEFAULT '',
  `user_title` varchar(50) DEFAULT NULL,
  `user_companyName` varchar(255) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_city` varchar(255) DEFAULT NULL,
  `user_zip` varchar(20) DEFAULT NULL,
  `user_state` varchar(100) DEFAULT NULL,
  `user_country` varchar(100) DEFAULT NULL,
  `user_FK_country_id` int(50) DEFAULT '0',
  `user_phone` varchar(100) DEFAULT NULL,
  `user_phone2` varchar(50) DEFAULT NULL,
  `user_mobile` varchar(50) DEFAULT NULL,
  `user_fax` varchar(100) DEFAULT NULL,
  `user_email` varchar(255) NOT NULL DEFAULT '',
  `user_www` varchar(255) DEFAULT NULL,
  `user_birthday` date NOT NULL DEFAULT '0000-00-00',
  `user_sex` enum('M','F') DEFAULT 'M',
  `user_confirmCode` varchar(200) DEFAULT NULL,
  `user_wantNewsletter` tinyint(1) UNSIGNED DEFAULT '1',
  `user_isInMailinglist` tinyint(1) UNSIGNED DEFAULT '0',
  `user_position` varchar(255) DEFAULT NULL,
  `user_department` varchar(255) DEFAULT NULL,
  `user_fiscalCode` varchar(32) DEFAULT NULL,
  `user_vat` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dump dei dati per la tabella `users_tbl`
--

INSERT INTO `users_tbl` (`user_id`, `user_FK_usergroup_id`, `user_FK_site_id`, `user_dateCreation`, `user_isActive`, `user_loginId`, `user_password`, `user_firstName`, `user_lastName`, `user_title`, `user_companyName`, `user_address`, `user_city`, `user_zip`, `user_state`, `user_country`, `user_FK_country_id`, `user_phone`, `user_phone2`, `user_mobile`, `user_fax`, `user_email`, `user_www`, `user_birthday`, `user_sex`, `user_confirmCode`, `user_wantNewsletter`, `user_isInMailinglist`, `user_position`, `user_department`, `user_fiscalCode`, `user_vat`) VALUES
(1, 1, NULL, '0000-00-00 00:00:00', 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Amministratore', 'Sito', '', '', '', '', '', '', NULL, 0, '', '', '', '', 'admin@admin.com', '', '0000-00-00', 'M', '', 1, 1, '', '', NULL, NULL);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `countries_tbl`
--
ALTER TABLE `countries_tbl`
  ADD PRIMARY KEY (`country_id`);

--
-- Indici per le tabelle `documents_detail_tbl`
--
ALTER TABLE `documents_detail_tbl`
  ADD PRIMARY KEY (`document_detail_id`),
  ADD KEY `document_detail_fk_document_id` (`document_detail_FK_document_id`),
  ADD KEY `document_detail_fk_language_id` (`document_detail_FK_language_id`),
  ADD KEY `document_detail_fk_user_id` (`document_detail_FK_user_id`),
  ADD KEY `document_detail_status` (`document_detail_status`);

--
-- Indici per le tabelle `documents_index_datetime_tbl`
--
ALTER TABLE `documents_index_datetime_tbl`
  ADD PRIMARY KEY (`document_index_datetime_id`),
  ADD KEY `document_index_datetime_fk` (`document_index_datetime_FK_document_detail_id`),
  ADD KEY `document_index_datetime_name` (`document_index_datetime_name`),
  ADD KEY `document_index_datetime_value` (`document_index_datetime_value`);

--
-- Indici per le tabelle `documents_index_date_tbl`
--
ALTER TABLE `documents_index_date_tbl`
  ADD PRIMARY KEY (`document_index_date_id`),
  ADD KEY `document_index_date_fk` (`document_index_date_FK_document_detail_id`),
  ADD KEY `document_index_date_name` (`document_index_date_name`),
  ADD KEY `document_index_date_value` (`document_index_date_value`);

--
-- Indici per le tabelle `documents_index_fulltext_tbl`
--
ALTER TABLE `documents_index_fulltext_tbl`
  ADD PRIMARY KEY (`document_index_fulltext_id`),
  ADD KEY `document_index_fulltext_FK_document_detail_id` (`document_index_fulltext_FK_document_detail_id`),
  ADD KEY `document_index_fulltext_name` (`document_index_fulltext_name`);

--
-- Indici per le tabelle `documents_index_int_tbl`
--
ALTER TABLE `documents_index_int_tbl`
  ADD PRIMARY KEY (`document_index_int_id`),
  ADD KEY `document_index_int_fk` (`document_index_int_FK_document_detail_id`),
  ADD KEY `document_index_int_name` (`document_index_int_name`),
  ADD KEY `document_index_int_value` (`document_index_int_value`);

--
-- Indici per le tabelle `documents_index_text_tbl`
--
ALTER TABLE `documents_index_text_tbl`
  ADD PRIMARY KEY (`document_index_text_id`),
  ADD KEY `document_index_text_fk` (`document_index_text_FK_document_detail_id`),
  ADD KEY `document_index_text_name` (`document_index_text_name`),
  ADD KEY `document_index_text_value` (`document_index_text_value`);

--
-- Indici per le tabelle `documents_index_time_tbl`
--
ALTER TABLE `documents_index_time_tbl`
  ADD PRIMARY KEY (`document_index_time_id`),
  ADD KEY `document_index_time_fk` (`document_index_time_FK_document_detail_id`),
  ADD KEY `document_index_time_name` (`document_index_time_name`),
  ADD KEY `document_index_time_value` (`document_index_time_value`);

--
-- Indici per le tabelle `documents_tbl`
--
ALTER TABLE `documents_tbl`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `document_type` (`document_type`),
  ADD KEY `document_FK_site_id` (`document_FK_site_id`);

--
-- Indici per le tabelle `ecommordersitems_tbl`
--
ALTER TABLE `ecommordersitems_tbl`
  ADD PRIMARY KEY (`orderitem_id`),
  ADD KEY `orderitem_FK_order_id` (`orderitem_FK_order_id`);

--
-- Indici per le tabelle `ecommorders_tbl`
--
ALTER TABLE `ecommorders_tbl`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `order_FK_user_id` (`order_FK_user_id`),
  ADD KEY `order_transactionCode` (`order_transactionCode`);

--
-- Indici per le tabelle `exif_tbl`
--
ALTER TABLE `exif_tbl`
  ADD PRIMARY KEY (`exif_id`),
  ADD KEY `exif_FK_media_id` (`exif_FK_media_id`);

--
-- Indici per le tabelle `iccd_theasaurs_tbl`
--
ALTER TABLE `iccd_theasaurs_tbl`
  ADD PRIMARY KEY (`iccd_theasaurs_id`);

--
-- Indici per le tabelle `joins_tbl`
--
ALTER TABLE `joins_tbl`
  ADD PRIMARY KEY (`join_id`),
  ADD KEY `join_FK_source_id` (`join_FK_source_id`),
  ADD KEY `join_FK_dest_id` (`join_FK_dest_id`),
  ADD KEY `join_objectName` (`join_objectName`);

--
-- Indici per le tabelle `languages_tbl`
--
ALTER TABLE `languages_tbl`
  ADD PRIMARY KEY (`language_id`),
  ADD KEY `language_FK_country_id` (`language_FK_country_id`),
  ADD KEY `language_isDefault` (`language_isDefault`),
  ADD KEY `language_order` (`language_order`);

--
-- Indici per le tabelle `massiveimporter_mappings_tbl`
--
ALTER TABLE `massiveimporter_mappings_tbl`
  ADD PRIMARY KEY (`massiveimporter_mapping_id`);

--
-- Indici per le tabelle `mediadetails_tbl`
--
ALTER TABLE `mediadetails_tbl`
  ADD PRIMARY KEY (`mediadetail_id`),
  ADD KEY `mediadetail_FK_media_id` (`mediadetail_FK_media_id`),
  ADD KEY `media_FK_language_id` (`media_FK_language_id`),
  ADD KEY `media_FK_user_id` (`media_FK_user_id`);

--
-- Indici per le tabelle `media_tbl`
--
ALTER TABLE `media_tbl`
  ADD PRIMARY KEY (`media_id`),
  ADD KEY `media_FK_site_id` (`media_FK_site_id`),
  ADD KEY `media_type` (`media_type`);

--
-- Indici per le tabelle `menudetails_tbl`
--
ALTER TABLE `menudetails_tbl`
  ADD PRIMARY KEY (`menudetail_id`),
  ADD KEY `menudetail_FK_menu_id` (`menudetail_FK_menu_id`),
  ADD KEY `menudetail_FK_language_id` (`menudetail_FK_language_id`);

--
-- Indici per le tabelle `menus_tbl`
--
ALTER TABLE `menus_tbl`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `menu_FK_site_id` (`menu_FK_site_id`),
  ADD KEY `menu_parentId` (`menu_parentId`),
  ADD KEY `menu_pageType` (`menu_pageType`);

--
-- Indici per le tabelle `niso_tbl`
--
ALTER TABLE `niso_tbl`
  ADD PRIMARY KEY (`niso_id`),
  ADD KEY `niso_FK_media_id` (`niso_FK_media_id`);

--
-- Indici per le tabelle `picoqueues_tbl`
--
ALTER TABLE `picoqueues_tbl`
  ADD PRIMARY KEY (`picoqueue_id`),
  ADD UNIQUE KEY `picoqueue_identifier` (`picoqueue_identifier`);

--
-- Indici per le tabelle `registry_tbl`
--
ALTER TABLE `registry_tbl`
  ADD PRIMARY KEY (`registry_id`),
  ADD KEY `registry_path` (`registry_path`);

--
-- Indici per le tabelle `roles_tbl`
--
ALTER TABLE `roles_tbl`
  ADD PRIMARY KEY (`role_id`),
  ADD KEY `role_name` (`role_name`);

--
-- Indici per le tabelle `simple_documents_index_datetime_tbl`
--
ALTER TABLE `simple_documents_index_datetime_tbl`
  ADD PRIMARY KEY (`simple_document_index_datetime_id`),
  ADD KEY `simple_document_index_datetime_fk` (`simple_document_index_datetime_FK_simple_document_id`),
  ADD KEY `simple_document_index_datetime_name` (`simple_document_index_datetime_name`),
  ADD KEY `simple_document_index_datetime_value` (`simple_document_index_datetime_value`);

--
-- Indici per le tabelle `simple_documents_index_date_tbl`
--
ALTER TABLE `simple_documents_index_date_tbl`
  ADD PRIMARY KEY (`simple_document_index_date_id`),
  ADD KEY `simple_document_index_date_fk` (`simple_document_index_date_FK_simple_document_id`),
  ADD KEY `simple_document_index_date_name` (`simple_document_index_date_name`),
  ADD KEY `simple_document_index_date_value` (`simple_document_index_date_value`);

--
-- Indici per le tabelle `simple_documents_index_fulltext_tbl`
--
ALTER TABLE `simple_documents_index_fulltext_tbl`
  ADD PRIMARY KEY (`simple_document_index_fulltext_id`),
  ADD KEY `simple_document_index_fulltext_FK_simple_document_detail_id` (`simple_document_index_fulltext_FK_simple_document_id`),
  ADD KEY `simple_document_index_fulltext_name` (`simple_document_index_fulltext_name`);

--
-- Indici per le tabelle `simple_documents_index_int_tbl`
--
ALTER TABLE `simple_documents_index_int_tbl`
  ADD PRIMARY KEY (`simple_document_index_int_id`),
  ADD KEY `simple_document_index_int_fk` (`simple_document_index_int_FK_simple_document_id`),
  ADD KEY `simple_document_index_int_name` (`simple_document_index_int_name`),
  ADD KEY `simple_document_index_int_value` (`simple_document_index_int_value`);

--
-- Indici per le tabelle `simple_documents_index_text_tbl`
--
ALTER TABLE `simple_documents_index_text_tbl`
  ADD PRIMARY KEY (`simple_document_index_text_id`),
  ADD KEY `simple_document_index_text_fk` (`simple_document_index_text_FK_simple_document_id`),
  ADD KEY `simple_document_index_text_name` (`simple_document_index_text_name`),
  ADD KEY `simple_document_index_text_value` (`simple_document_index_text_value`);

--
-- Indici per le tabelle `simple_documents_index_time_tbl`
--
ALTER TABLE `simple_documents_index_time_tbl`
  ADD PRIMARY KEY (`simple_document_index_time_id`),
  ADD KEY `simple_document_index_time_fk` (`simple_document_index_time_FK_simple_document_id`),
  ADD KEY `simple_document_index_time_name` (`simple_document_index_time_name`),
  ADD KEY `simple_document_index_time_value` (`simple_document_index_time_value`);

--
-- Indici per le tabelle `simple_documents_tbl`
--
ALTER TABLE `simple_documents_tbl`
  ADD PRIMARY KEY (`simple_document_id`),
  ADD KEY `simple_document_type` (`simple_document_type`),
  ADD KEY `simple_document_FK_site_id` (`simple_document_FK_site_id`);

--
-- Indici per le tabelle `usergroups_tbl`
--
ALTER TABLE `usergroups_tbl`
  ADD PRIMARY KEY (`usergroup_id`),
  ADD KEY `usergroup_FK_site_id` (`usergroup_FK_site_id`);

--
-- Indici per le tabelle `userlogs_tbl`
--
ALTER TABLE `userlogs_tbl`
  ADD PRIMARY KEY (`userlog_id`),
  ADD KEY `userlog_FK_user_id` (`userlog_FK_user_id`);

--
-- Indici per le tabelle `users_tbl`
--
ALTER TABLE `users_tbl`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_FK_usergroup_id` (`user_FK_usergroup_id`),
  ADD KEY `user_FK_site_id` (`user_FK_site_id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `countries_tbl`
--
ALTER TABLE `countries_tbl`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT per la tabella `documents_detail_tbl`
--
ALTER TABLE `documents_detail_tbl`
  MODIFY `document_detail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT per la tabella `documents_index_datetime_tbl`
--
ALTER TABLE `documents_index_datetime_tbl`
  MODIFY `document_index_datetime_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_date_tbl`
--
ALTER TABLE `documents_index_date_tbl`
  MODIFY `document_index_date_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT per la tabella `documents_index_fulltext_tbl`
--
ALTER TABLE `documents_index_fulltext_tbl`
  MODIFY `document_index_fulltext_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT per la tabella `documents_index_int_tbl`
--
ALTER TABLE `documents_index_int_tbl`
  MODIFY `document_index_int_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT per la tabella `documents_index_text_tbl`
--
ALTER TABLE `documents_index_text_tbl`
  MODIFY `document_index_text_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=450;

--
-- AUTO_INCREMENT per la tabella `documents_index_time_tbl`
--
ALTER TABLE `documents_index_time_tbl`
  MODIFY `document_index_time_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_tbl`
--
ALTER TABLE `documents_tbl`
  MODIFY `document_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT per la tabella `ecommordersitems_tbl`
--
ALTER TABLE `ecommordersitems_tbl`
  MODIFY `orderitem_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ecommorders_tbl`
--
ALTER TABLE `ecommorders_tbl`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `exif_tbl`
--
ALTER TABLE `exif_tbl`
  MODIFY `exif_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `iccd_theasaurs_tbl`
--
ALTER TABLE `iccd_theasaurs_tbl`
  MODIFY `iccd_theasaurs_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `joins_tbl`
--
ALTER TABLE `joins_tbl`
  MODIFY `join_id` int(1) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `languages_tbl`
--
ALTER TABLE `languages_tbl`
  MODIFY `language_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `massiveimporter_mappings_tbl`
--
ALTER TABLE `massiveimporter_mappings_tbl`
  MODIFY `massiveimporter_mapping_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `mediadetails_tbl`
--
ALTER TABLE `mediadetails_tbl`
  MODIFY `mediadetail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT per la tabella `media_tbl`
--
ALTER TABLE `media_tbl`
  MODIFY `media_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT per la tabella `menudetails_tbl`
--
ALTER TABLE `menudetails_tbl`
  MODIFY `menudetail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=486;

--
-- AUTO_INCREMENT per la tabella `menus_tbl`
--
ALTER TABLE `menus_tbl`
  MODIFY `menu_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT per la tabella `niso_tbl`
--
ALTER TABLE `niso_tbl`
  MODIFY `niso_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `picoqueues_tbl`
--
ALTER TABLE `picoqueues_tbl`
  MODIFY `picoqueue_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `registry_tbl`
--
ALTER TABLE `registry_tbl`
  MODIFY `registry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `roles_tbl`
--
ALTER TABLE `roles_tbl`
  MODIFY `role_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `simple_documents_index_datetime_tbl`
--
ALTER TABLE `simple_documents_index_datetime_tbl`
  MODIFY `simple_document_index_datetime_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `simple_documents_index_date_tbl`
--
ALTER TABLE `simple_documents_index_date_tbl`
  MODIFY `simple_document_index_date_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `simple_documents_index_fulltext_tbl`
--
ALTER TABLE `simple_documents_index_fulltext_tbl`
  MODIFY `simple_document_index_fulltext_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `simple_documents_index_int_tbl`
--
ALTER TABLE `simple_documents_index_int_tbl`
  MODIFY `simple_document_index_int_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `simple_documents_index_text_tbl`
--
ALTER TABLE `simple_documents_index_text_tbl`
  MODIFY `simple_document_index_text_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `simple_documents_index_time_tbl`
--
ALTER TABLE `simple_documents_index_time_tbl`
  MODIFY `simple_document_index_time_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `simple_documents_tbl`
--
ALTER TABLE `simple_documents_tbl`
  MODIFY `simple_document_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `usergroups_tbl`
--
ALTER TABLE `usergroups_tbl`
  MODIFY `usergroup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `userlogs_tbl`
--
ALTER TABLE `userlogs_tbl`
  MODIFY `userlog_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `users_tbl`
--
ALTER TABLE `users_tbl`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
