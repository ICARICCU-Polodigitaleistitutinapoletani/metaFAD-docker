-- phpMyAdmin SQL Dump
-- version 4.7.6
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Creato il: Dic 11, 2017 alle 15:31
-- Versione del server: 5.7.18
-- Versione PHP: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `metafad_ecommerce`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_detail_tbl`
--

DROP TABLE IF EXISTS `documents_detail_tbl`;
CREATE TABLE `documents_detail_tbl` (
  `document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_document_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_language_id` int(10) UNSIGNED NOT NULL,
  `document_detail_FK_user_id` int(10) UNSIGNED NOT NULL,
  `document_detail_modificationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `document_detail_status` varchar(9) NOT NULL DEFAULT 'DRAFT',
  `document_detail_translated` tinyint(1) NOT NULL DEFAULT '0',
  `document_detail_isVisible` tinyint(1) DEFAULT '1',
  `document_detail_object` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_datetime_tbl`
--

DROP TABLE IF EXISTS `documents_index_datetime_tbl`;
CREATE TABLE `documents_index_datetime_tbl` (
  `document_index_datetime_id` int(10) UNSIGNED NOT NULL,
  `document_index_datetime_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_datetime_name` varchar(70) NOT NULL,
  `document_index_datetime_value` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_date_tbl`
--

DROP TABLE IF EXISTS `documents_index_date_tbl`;
CREATE TABLE `documents_index_date_tbl` (
  `document_index_date_id` int(10) UNSIGNED NOT NULL,
  `document_index_date_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_date_name` varchar(70) NOT NULL,
  `document_index_date_value` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_fulltext_tbl`
--

DROP TABLE IF EXISTS `documents_index_fulltext_tbl`;
CREATE TABLE `documents_index_fulltext_tbl` (
  `document_index_fulltext_id` int(10) UNSIGNED NOT NULL,
  `document_index_fulltext_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_fulltext_name` varchar(70) NOT NULL,
  `document_index_fulltext_value` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_int_tbl`
--

DROP TABLE IF EXISTS `documents_index_int_tbl`;
CREATE TABLE `documents_index_int_tbl` (
  `document_index_int_id` int(10) UNSIGNED NOT NULL,
  `document_index_int_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_int_name` varchar(70) NOT NULL,
  `document_index_int_value` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_text_tbl`
--

DROP TABLE IF EXISTS `documents_index_text_tbl`;
CREATE TABLE `documents_index_text_tbl` (
  `document_index_text_id` int(10) UNSIGNED NOT NULL,
  `document_index_text_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_text_name` varchar(70) NOT NULL,
  `document_index_text_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_index_time_tbl`
--

DROP TABLE IF EXISTS `documents_index_time_tbl`;
CREATE TABLE `documents_index_time_tbl` (
  `document_index_time_id` int(10) UNSIGNED NOT NULL,
  `document_index_time_FK_document_detail_id` int(10) UNSIGNED NOT NULL,
  `document_index_time_name` varchar(70) NOT NULL,
  `document_index_time_value` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `documents_tbl`
--

DROP TABLE IF EXISTS `documents_tbl`;
CREATE TABLE `documents_tbl` (
  `document_id` int(10) UNSIGNED NOT NULL,
  `document_type` varchar(255) DEFAULT NULL,
  `document_creationDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `document_FK_site_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ecommlicenses_tbl`
--

DROP TABLE IF EXISTS `ecommlicenses_tbl`;
CREATE TABLE `ecommlicenses_tbl` (
  `license_id` int(10) UNSIGNED NOT NULL,
  `license_title` varchar(255) NOT NULL,
  `license_type` text NOT NULL,
  `license_stream` longtext,
  `license_price` double NOT NULL,
  `license_description` text NOT NULL,
  `instituteKey` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ecommordersitems_tbl`
--

DROP TABLE IF EXISTS `ecommordersitems_tbl`;
CREATE TABLE `ecommordersitems_tbl` (
  `orderitem_id` int(10) UNSIGNED NOT NULL,
  `orderitem_FK_order_id` int(10) UNSIGNED NOT NULL,
  `orderitem_price` decimal(10,2) NOT NULL,
  `orderitem_code` varchar(255) NOT NULL,
  `orderitem_FK_license_id` int(10) DEFAULT '1',
  `orderitem_downloads` int(2) NOT NULL DEFAULT '0',
  `orderitem_title` varchar(255) NOT NULL DEFAULT '',
  `orderitem_url` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ecommorders_tbl`
--

DROP TABLE IF EXISTS `ecommorders_tbl`;
CREATE TABLE `ecommorders_tbl` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `order_code` varchar(50) NOT NULL,
  `order_date` datetime NOT NULL,
  `order_state` enum('open','completed') NOT NULL,
  `order_FK_user_id` int(10) UNSIGNED NOT NULL,
  `order_transactionCode` varchar(50) DEFAULT NULL,
  `order_bankAnswer` int(4) DEFAULT NULL,
  `instituteKey` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struttura della tabella `ecommrequests_tbl`
--

DROP TABLE IF EXISTS `ecommrequests_tbl`;
CREATE TABLE `ecommrequests_tbl` (
  `request_id` int(10) UNSIGNED NOT NULL,
  `request_title` varchar(255) NOT NULL,
  `request_date` datetime NOT NULL,
  `request_state` varchar(20) NOT NULL,
  `request_FK_user_id` int(10) UNSIGNED NOT NULL,
  `request_user_firstName` varchar(100) DEFAULT NULL,
  `request_user_lastName` varchar(100) DEFAULT NULL,
  `request_notify` varchar(50) DEFAULT NULL,
  `instituteKey` varchar(255) NOT NULL,
  `request_type` varchar(10) NOT NULL,
  `request_text` text,
  `request_object_id` int(11) NOT NULL,
  `request_operator` text,
  `request_operator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `documents_detail_tbl`
--
ALTER TABLE `documents_detail_tbl`
  ADD PRIMARY KEY (`document_detail_id`),
  ADD KEY `document_detail_fk_document_id` (`document_detail_FK_document_id`),
  ADD KEY `document_detail_fk_language_id` (`document_detail_FK_language_id`),
  ADD KEY `document_detail_fk_user_id` (`document_detail_FK_user_id`),
  ADD KEY `document_detail_status` (`document_detail_status`);

--
-- Indici per le tabelle `documents_index_datetime_tbl`
--
ALTER TABLE `documents_index_datetime_tbl`
  ADD PRIMARY KEY (`document_index_datetime_id`),
  ADD KEY `document_index_datetime_fk` (`document_index_datetime_FK_document_detail_id`),
  ADD KEY `document_index_datetime_name` (`document_index_datetime_name`),
  ADD KEY `document_index_datetime_value` (`document_index_datetime_value`);

--
-- Indici per le tabelle `documents_index_date_tbl`
--
ALTER TABLE `documents_index_date_tbl`
  ADD PRIMARY KEY (`document_index_date_id`),
  ADD KEY `document_index_date_fk` (`document_index_date_FK_document_detail_id`),
  ADD KEY `document_index_date_name` (`document_index_date_name`),
  ADD KEY `document_index_date_value` (`document_index_date_value`);

--
-- Indici per le tabelle `documents_index_fulltext_tbl`
--
ALTER TABLE `documents_index_fulltext_tbl`
  ADD PRIMARY KEY (`document_index_fulltext_id`),
  ADD KEY `document_index_fulltext_FK_document_detail_id` (`document_index_fulltext_FK_document_detail_id`),
  ADD KEY `document_index_fulltext_name` (`document_index_fulltext_name`);
ALTER TABLE `documents_index_fulltext_tbl` ADD FULLTEXT KEY `document_index_fulltext_value` (`document_index_fulltext_value`);

--
-- Indici per le tabelle `documents_index_int_tbl`
--
ALTER TABLE `documents_index_int_tbl`
  ADD PRIMARY KEY (`document_index_int_id`),
  ADD KEY `document_index_int_fk` (`document_index_int_FK_document_detail_id`),
  ADD KEY `document_index_int_name` (`document_index_int_name`),
  ADD KEY `document_index_int_value` (`document_index_int_value`);

--
-- Indici per le tabelle `documents_index_text_tbl`
--
ALTER TABLE `documents_index_text_tbl`
  ADD PRIMARY KEY (`document_index_text_id`),
  ADD KEY `document_index_text_fk` (`document_index_text_FK_document_detail_id`),
  ADD KEY `document_index_text_name` (`document_index_text_name`),
  ADD KEY `document_index_text_value` (`document_index_text_value`);

--
-- Indici per le tabelle `documents_index_time_tbl`
--
ALTER TABLE `documents_index_time_tbl`
  ADD PRIMARY KEY (`document_index_time_id`),
  ADD KEY `document_index_time_fk` (`document_index_time_FK_document_detail_id`),
  ADD KEY `document_index_time_name` (`document_index_time_name`),
  ADD KEY `document_index_time_value` (`document_index_time_value`);

--
-- Indici per le tabelle `documents_tbl`
--
ALTER TABLE `documents_tbl`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `document_type` (`document_type`),
  ADD KEY `document_FK_site_id` (`document_FK_site_id`);

--
-- Indici per le tabelle `ecommlicenses_tbl`
--
ALTER TABLE `ecommlicenses_tbl`
  ADD PRIMARY KEY (`license_id`);

--
-- Indici per le tabelle `ecommordersitems_tbl`
--
ALTER TABLE `ecommordersitems_tbl`
  ADD PRIMARY KEY (`orderitem_id`),
  ADD KEY `orderitem_FK_order_id` (`orderitem_FK_order_id`);

--
-- Indici per le tabelle `ecommorders_tbl`
--
ALTER TABLE `ecommorders_tbl`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `order_FK_user_id` (`order_FK_user_id`),
  ADD KEY `order_transactionCode` (`order_transactionCode`);

--
-- Indici per le tabelle `ecommrequests_tbl`
--
ALTER TABLE `ecommrequests_tbl`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `order_FK_user_id` (`request_FK_user_id`),
  ADD KEY `order_transactionCode` (`request_notify`),
  ADD KEY `request_operator_id` (`request_operator_id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `documents_detail_tbl`
--
ALTER TABLE `documents_detail_tbl`
  MODIFY `document_detail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_datetime_tbl`
--
ALTER TABLE `documents_index_datetime_tbl`
  MODIFY `document_index_datetime_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_date_tbl`
--
ALTER TABLE `documents_index_date_tbl`
  MODIFY `document_index_date_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_fulltext_tbl`
--
ALTER TABLE `documents_index_fulltext_tbl`
  MODIFY `document_index_fulltext_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_int_tbl`
--
ALTER TABLE `documents_index_int_tbl`
  MODIFY `document_index_int_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_text_tbl`
--
ALTER TABLE `documents_index_text_tbl`
  MODIFY `document_index_text_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_index_time_tbl`
--
ALTER TABLE `documents_index_time_tbl`
  MODIFY `document_index_time_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `documents_tbl`
--
ALTER TABLE `documents_tbl`
  MODIFY `document_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ecommlicenses_tbl`
--
ALTER TABLE `ecommlicenses_tbl`
  MODIFY `license_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ecommordersitems_tbl`
--
ALTER TABLE `ecommordersitems_tbl`
  MODIFY `orderitem_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ecommorders_tbl`
--
ALTER TABLE `ecommorders_tbl`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la tabella `ecommrequests_tbl`
--
ALTER TABLE `ecommrequests_tbl`
  MODIFY `request_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
